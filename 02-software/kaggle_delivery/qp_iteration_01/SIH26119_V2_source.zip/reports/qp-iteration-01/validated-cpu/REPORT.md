# V2 validation evidence

Generated correctness: PASS.

| Group | Passed | Total |
| --- | ---: | ---: |
| generated_lp | 120 | 120 |
| generated_milp | 40 | 40 |
| generated_qp | 30 | 30 |
| generated_mixed | 40 | 40 |
| generated_qp_equalities | 21 | 21 |
| industrial | 4 | 4 |
| miplib | 4 | 4 |
| miplib2017 | 0 | 3 |
| netlib | 12 | 12 |
| qplib | 2 | 3 |
| qplib_independent_kkt | 3 | 3 |
| scale | 6 | 6 |

The qplib group still requires an independently optimal reference result. The separate qplib_independent_kkt group checks returned primal/dual vectors on the original QPLIB data; strict diagonal models additionally report a separable Lagrangian bound and numerical gap in benchmarks.json and reference JSON. No reference timeout is relabeled as a reference pass.

All incomplete public cases remain in benchmarks.json. Scale cases are synthetic tridiagonal convex box QPs with planted solutions; they do not establish general million-variable industrial capability.

GPU status: not_run_no_cuda_requested.

Timing includes setup, transfer and solution checks inside the solver; process time also includes startup. All scale repetitions run sequentially. RSS is sampled, not an exact peak.
