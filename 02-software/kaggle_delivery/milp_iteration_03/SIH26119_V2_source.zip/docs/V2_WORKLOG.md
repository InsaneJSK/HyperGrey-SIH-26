# SIH26119 implementation worklog

This continues the supplied V1 conversation and evidence. The user's current
instruction is to build a strong, working submission covering the PS, with tests,
phase reports, and explicit limitations. Existing V1 reports are historical.

## Delivery contract

- Initial classes: LP, MILP, and continuous convex QP. The PS asks for an
  architecture extensible to MIQP/NLP/MINLP; it does not require all of these
  extensions to be implemented initially. Nonconvex-QP scope is unresolved.
- All optimization and numerical algorithms in the core are our implementation.
  External solver packages are permitted only as isolated validation references.
- Keep unsuccessful benchmark runs. Optimal status requires numerical checks.
- GPU performance must be measured on available hardware, never inferred from
  a CPU run or a kernel-only timing.

## Current machine (2026-09-14)

Intel Core i5-10210U, 4 physical cores / 8 logical processors,
42,523,881,472 bytes physical RAM, Intel UHD Graphics. GCC 14.2.0 and CMake
3.30.4 are available. NVIDIA hardware is not detected. The user confirmed
30 September 2026 as the deadline and Kaggle as the GPU execution environment.

## Implementation and verification sequence

1. Preserve V1; establish a modern-compiler baseline.
2. Add sparse LP computation, reusable basis solves, and numerical certificates.
3. Add MILP presolve, incumbent heuristics, improved search and reusable LP state.
4. Strengthen constrained convex QP, scaling, PSD checks and stopping evidence.
5. Add multicore operations and an optional GPU backend with device detection.
6. Exercise analytical, generated, old-failure and broader public datasets;
   record source/input/binary hashes, hardware, timing, memory and reference checks.
7. Add literature-grounded industrial cases and submission documentation,
   including API/CLI usage, architecture, provenance, results and unresolved gaps.

This list records intended work, not implemented capabilities. Completed phases
and final evidence will be recorded below as they are verified.

## Implemented and assessed

- Preserved V1 source and executable in `reports/v2-baseline/`.
- Added sparse primal/dual revised simplex, own LU/eta basis algebra and warm
  starts; all 120 generated LP tests and the 12-instance Netlib subset passed.
- Added propagation, root cover cuts, diving and integer-candidate polishing;
  all 40 binary and 40 mixed/general-integer regressions passed. All four
  historical MIPLIB cases completed to the stated tolerance in the V2 run.
- Added scaled ADMM/PCG, bounded active-set polishing, broader sparse PSD tests,
  and a small structured diagonal-QP dual-Newton path. Generated QP checks pass;
  QPLIB 9002 remains incomplete.
- Added OpenMP and optional resident CUDA box-QP code. Repeated CPU scale tests
  through one million variables passed; the later P100 return also passed all
  three selected CUDA scale cases (see the GPU return entry below).
- Added three MIPLIB 2017 stress cases, four industrial/literature models,
  a consolidated evidence runner, and a separate self-contained Kaggle notebook.
- Added current requirements, architecture, limitation and handoff documents.

The deadline is now confirmed as 30 September 2026. See `V2_REMAINING.md` for
the exact Kaggle return bundle and outside information still needed.

## Kaggle usability revision

After the user reported a notebook error and requested a simpler iteration,
the delivery was reduced to two code cells. It uses the current Kaggle Python,
standard pip/subprocess, explicit working paths, a single timing repetition,
and a results ZIP on normal installation/build/check errors. Missing GPU/CUDA
is labeled CPU-only. The numerical solver was not changed. The original
traceback was not supplied, so its exact cause is not asserted.

The user subsequently reported a notebook/kernel size limit of less than 1 MB.
The source/data payload was moved out of the notebook into a required companion
ZIP, attached as a private Kaggle input dataset. The notebook automatically
loads zipped or unpacked inputs and verifies their hashes before running.
No numerical solver or benchmark scope changes were needed for this packaging fix.

## First Kaggle GPU return, 14 September 2026

Imported Downloads/sih26119_kaggle_results.zip and preserved it unchanged in
reports/kaggle-gpu-01/ with the submitted source/notebook. Audited 115 source
files, 59 runtime-source hashes, original benchmark checks and all counts.
The P100 run passed 230 generated cases, 12/12 Netlib, 4/4 historical MIPLIB,
2/3 QPLIB, 0/3 additional MIPLIB, 4/4 application cases and 9/9 scale checks.
The one-million-variable box QP took 2.9818 s GPU vs 16.7640 s CPU1 (5.62x,
single pass only). GPU was slower at 1,000 variables. The same four hard cases
remain incomplete. The reporting fix for HiGHS native output worked.

All GPU-memory fields were null; old exceptions were suppressed. Added a tested
diagnostic sampler for the next snapshot, keeping whole-device memory distinct
from process-attributed memory. No numerical core changes or rerun of the
unchanged Kaggle notebook are needed for this evidence import.

## MILP iteration 01, 14 September 2026

User authorized starting the next targeted engineering iteration. Preserved
the original executable (SHA 9740e7ee...) at build-v2 and as an explicit
reports/milp-iteration-01 baseline copy; the original Kaggle delivery and return
remain untouched. New build: build-milp-iter1. The first candidate SHA was
859060f9...; the retained post-budget-fix candidate SHA is 696b8518....

Implemented our own bounded L1 feasibility pump, deterministic perturbation,
general-integer absolute-distance auxiliaries and fixed-integer polishing.
Added --no-pump, counters/first-incumbent time, finite-coordinate guard and
correct heuristic sub-LP time allocation. Acceptance tolerances and proof-bound
semantics are unchanged. Added analytical tests for these contracts.

Paired exploratory checks: binkar10_1 now has a checked incumbent 7297.320029;
the baseline and no-pump control had none. The first candidate's full CPU run reproduces
that candidate at 19.61 seconds, final reported gap 8.7881%, independently
zero original constraint/integrality violation. It is NOT proven optimal.
blend2 still has no incumbent; markshare_4_0 still has the old approximate-33
incumbent and a large gap. Deeper-backtracking and broader-pump experiments
did not fix blend2 and were discarded; exact exploratory sources/results are
retained in experiment-01/02/03.

First candidate full CPU gate: 230/230 generated, 3/3 CTest, 12/12 Netlib,
4/4 historical MILP, 2/3 QPLIB, 0/3 completed modern MILP, 4/4 application
models, 6/6 CPU scale checks through one million variables. Full evidence:
reports/milp-iteration-01/final-cpu. No LP/QP/CUDA numerical changes this cycle;
QPLIB 9002 remains a separate next work item. No new GPU performance claim.

A further repeat of that first candidate missed its incumbent; preserved in
final-ablation/. The shrinking pump allowance after root cuts was too fragile.
An early-pump/capped-cut experiment also failed twice (experiment-04, retained
as unsuccessful evidence). The retained fix instead reserves up to five
seconds for a post-cut pump, with safe rollback of incomplete cut attempts.
Two exact-binary repeats in experiment-05 independently verified objective
7297.320029, first incumbents 21.7381 and 20.7504 seconds, gaps about 8.79%.
Current exact-binary full evidence is validated-cpu/, not the older final-cpu/.
That full gate reproduced the candidate at 19.7005 seconds with 8.8121% final
gap and zero independently measured feasibility/integrality violation.

Specific next MILP performance investigation: new cut rows currently force a
cold LP solve. Safely extending the old basis across added rows may reduce
root overhead; it requires independent primal/dual checks and a dedicated
iteration, not a guessed basis transfer. blend2 is a search failure, not a
claim that the original model is infeasible.

Kaggle packaging can now select matching CPU evidence and refuses stale core
hashes. The next separate delivery is kaggle_delivery/milp_iteration_01;
same small two-cell notebook / companion private-input ZIP workflow. Request
the NEW results ZIP to validate this snapshot on Linux/P100 and capture the
previously added GPU-memory diagnostics. The old P100 baseline stays historical.

## Second Kaggle return, 14 September 2026

User returned Downloads/sih26119_kaggle_results (1).zip. Audited/preserved as
reports/kaggle-gpu-02; exact source f9b8a366... matches MILP iteration 01.
128 source files and 63 runtime hashes verified. Completed CUDA/P100 run:
230/230 generated, 12/12 Netlib, 4/4 historical MILP, 4/4 application cases,
2/3 QPLIB, 0/3 completed modern MILP, 9/9 scale (including 3/3 CUDA).

binkar10_1 improvement confirmed on Kaggle: feasible 7297.320029 at 13.7940 s,
549 nodes at 30 s, bound 6658.583810, gap 8.7518%. Kaggle and fresh local
independent readers both measure zero original feasibility/integrality
violation. Not an optimality proof; the other three hard cases remain open.
P100 million-variable synthetic box QP: 2.96186 s vs CPU1 15.94096 s (5.38x),
single pass. GPU still loses at 1,000 variables. No QP/CUDA core changes.

Memory diagnostics now show NVML successful but no matching solver PID,
despite one visible GPU process. Whole-device peaks are available; solver-only
VRAM is not. Cause of PID mismatch is not established. Do not relabel device
memory as process memory. Current snapshot now has its own GPU evidence.

No new notebook or rerun needed for this import. Next numerical priority remains
constrained QPLIB 9002. See reports/kaggle-gpu-02/REPORT.md and AUDIT.json.

## QP iteration 01, 14 September 2026

User authorized starting the constrained-QP cycle. Preserved the MILP build and
both returned Kaggle snapshots. New build is build-qp-iter1, CLI SHA-256
4786604e43e70efdaf92c93c9294df1fa12fc71aa97358c2ebfc89ca509c8a2c.

9002 is strictly positive diagonal with 1,649 equality rows and 2,890 columns;
curvature spans about 11 orders and some bounds are around 1e11. Removing the
old 512-variable specialist cap alone stalled above tolerance. Magnitude
normalization after curvature whitening, with correctly rescaled duals, solves
it. Added structure-based bounded dispatch and exact separable numerical dual
bounds; strict-diagonal acceptance now also requires relative gap <= tolerance.
No tolerance relaxation, name-based routing, coefficient dropping or external
solver use in the core. LP/MILP/CUDA numerical sources are unchanged.

Retained-source full gate: CTest 3/3, 251/251 generated (21 new equality cases),
7/7 adversarial certificate checks, 12/12 Netlib, 4/4 historical MILP, 4/4
application examples and 6/6 CPU scales through one million variables. Original
QPLIB candidate KKT checks now pass 3/3; completed-reference comparisons stay
2/3 because the unchanged OSQP 9002 reference protocol still times out.

Final 9002 repeats: 4.2754, 4.1924, 4.8112 seconds, all 180 iterations. Independent
objective 5698097498.566484, numerical lower bound 5698097498.119152, relative
feasibility 8.5718e-8, stationarity 2.4132e-16, complementarity 4.1248e-11,
relative gap 7.8506e-11. Maximum absolute violation is 2.3810; do not confuse
relative acceptance on huge values with exact/absolute feasibility.

binkar10_1's feasible 7297.320029 incumbent is retained; modern MILP completed
score remains 0/3. All unsuccessful experiments and harness setup/scoring
errors are preserved with explanations. Current evidence: reports/qp-iteration-01
validated-cpu and final-repeats. See REPORT.md and docs/DIAGONAL_QP_METHOD.md.

Separate next delivery: kaggle_delivery/qp_iteration_01, same small two-cell
notebook and matching external private-input source ZIP. It requires a NEW
Kaggle return; old P100 evidence must not be attributed to this snapshot.
No MIQP/NLP/MINLP/nonconvex scope expansion in this iteration. Remaining work:
modern MILP gap/feasibility progress, broader QP tests, industrial inputs, repeated
equal-accuracy measurements, organizer clarification and submission material.

## MILP iteration 02 — focused Kaggle experiment

User wants faster hard-MILP iteration without waiting for the QP Kaggle return.
Added opt-in --branching reliability; existing fractionality remains default.
Pseudocost learning and bounded trial LPs only select variables, never manufacture
proof bounds or prune nodes. Original candidate checks remain unchanged. Added
branching counters, trial time and incumbent_trace to JSON. New build is
build-milp-iter2; build-qp-iter1 and earlier deliveries remain preserved.

Local smoke: 160 generated checks across BOTH strategies, CTest 3/3. Six hard
runs at equal 15-second / 250,000-node budgets, all time-limited. markshare_4_0
incumbent improves from about 21 (control) to 13 (reliability); binkar10_1 both
7127.780038; blend2 neither finds a candidate. All four incumbents independently
verified. Zero-second references were candidate checks, not optimum comparisons.

Dedicated delivery kaggle_delivery/milp_iteration_02: 180 seconds and 250,000
nodes per model/strategy, 3 models x 2 strategies, 160 generated checks and
30-second independent references. CPU only, no GPU quota needed. Notebook
remains below 1 MB with matching external ZIP as private input. Expected return
is sih26119_milp_results.zip, not the previous generic Kaggle filename. It does
not run the QP/GPU sweep; reliability is not yet promoted to default. See
reports/milp-iteration-02/REPORT.md and local-smoke for exact evidence.

## Focused MILP Kaggle return, 14 September 2026

Imported Downloads/sih26119_milp_results.zip as reports/kaggle-milp-01.
Returned hash f70ee00fcd9df87da3c9e9ef759c8558747d2b350de431ddf2a98261fbe497e8;
source a200a445... matches the delivered MILP iteration 02 exactly. Verified
140 packaged / 71 runtime hashes, CMake CPU-only, CTest 3/3 and generated160/160.
Fresh local original-MPS checks verify all four hard-case incumbents.

At equal 180 s / 250k-node caps: markshare control reaches objective about5
(node limit,164.17s), reliability about7 (time limit,180.04s). The longer run
reverses the short local ranking; do NOT promote reliability to default.
binkar both7297.320029, control gap8.6587%, reliability8.5743%; neither improves
its first incumbent at~14.3s. Local15s7127 incumbent is not reproduced: local
15cuts/1rollback/2pump projections versus Kaggle18cuts/0rollback/1projection.

blend2 neither has an incumbent; both stop EARLY with iteration_limit at41.27s
and53.92s. Source confirms default10,000-iteration cap per LP relaxation, then
MILP abort/requeue on unresolved LP. This is not the250-step trial-probe cap.
Exact cause of the difficult LP remains unmeasured; capture failing node/basis
and implement bounded recovery before simply raising limits. Stronger branching
alone does not solve this termination issue.

Zero hard optimum completions. Reference solves blend2 at7.598985 but times out
on markshare/incumbent3 and binkar/incumbent6746.760023. Keep those latter values
as reference incumbents, not optimal values. No core/default changed on import.
No rerun of unchanged notebook needed. Next bounded work: tree-LP recovery and
post-incumbent improvement, preserving all proof/candidate validation rules.

## MILP iteration 03 — recovery and incumbent improvement

Implemented opt-in LP cold/dense recovery, proof-preserving deferred nodes,
LP-guided restricted neighbourhood search, and first-failed-LP model/input-basis
capture. Default branching stays fractionality; new options remain opt-in.
Final build build-milp-iter3 SHA-256
ae6d294de68e932ae3c48ea784a34651a040cc530f1e91540eab0ad96e88e19f.
Earlier builds/deliveries/returns are preserved, plus the initial iteration-03
binary and changed MILP source before the final repair-handling fix.

Final-source CTest3/3 and generated240/240 pass. Six equal15s hard smoke runs
yield four independently checked candidates: markshare both~21, blend2 none,
binkar control7297.320029 vs new6810.690026 (gap8.8011% vs2.2929%). Initial
60s experiment reached binkar6789.670035 vs7297.320029; those distinct-source
results are retained with a failed blend2 gate, not relabeled as final evidence.

The initial blend2 cold recovery succeeded, then a nearly integral candidate
failed strict absolute feasibility and its exact-fixing repair failed. Final
handling retains that node/bound unresolved and continues the other tree work.
The final equal90s blend2 comparison: control stops33.49s/3762nodes at LP cap;
new mode reaches90.03s/8170nodes, recovers3/3 LPs, retains2 unresolved nodes,
and improves lower bound7.468466152 to7.564874474. Still no valid incumbent.

Captured failing node4615/depth19 reaches10000 warm pivots; cold sparse513
and dense546 pivots both solve to7.7347385328076, agreeing with independent
HiGHS. This supports recovery but does not prove the exact warm-stall cause.
The first cold-diagnostic reference invocation missed a required candidate
argument; its error is retained, the helper is fixed, and the rerun passes.

Separate delivery kaggle_delivery/milp_iteration_03: two-cell sub-1MB notebook,
matching private input ZIP, CPU-only, six180s/250k hard runs and240 generated
checks. Return sih26119_milp_results.zip. New Kaggle execution remains pending.
No general speedup, hard optimum completion, new GPU evidence or submission
ranking is claimed. See reports/milp-iteration-03/REPORT.md for exact evidence.
