# SIH26119: V2 requirement coverage

The supplied `Problem Statement.txt` is the controlling source. Its final
dataset paragraph is truncated; no missing requirement is inferred. This matrix
distinguishes implemented capability from the PS's broader performance ambition.

| PS area | V2 capability/evidence | Remaining obligation |
| --- | --- | --- |
| Own solver core | CMake compiles our numerical and optimization code; references are separate processes | Preserve provenance and obtain organizer interpretation of permitted infrastructure |
| LP | Sparse revised primal/dual simplex, scaling, basis reuse, numerical checks and recession rays | Broader ill-conditioning coverage and production numerical recovery |
| MILP | Own branch-and-cut baseline, propagation, binary cover cuts, diving and gap tracking | Incomplete modern MIPLIB cases; stronger cuts, branching and heuristics |
| QP | Continuous convex box/general-linear paths; sparse PSD tests and numerical KKT checking | QPLIB 9002 convergence; general nonconvex scope clarification |
| MIQP/NLP/MINLP extension | Separate model, sparse algebra and algorithm APIs | Algorithms for these future classes are not implemented |
| Sparse algebra | Sparse input/CSR products, LU and eta updates | Fill growth can still be expensive; no production sparse reordering package |
| Multicore | OpenMP QP products and iterations; repeated 1/4-thread measurements | Wider workloads; no parallel MILP tree or parallel simplex |
| GPU | P100 compiled/executed our CUDA box-QP kernels; all three planted CUDA scale cases passed through one million variables | Single timing pass only; repeated measurements, public box-QP GPU checks and reliable memory diagnostics |
| Numerical robustness | Analytical/cycling, extreme row scaling, planted certificates, mixed-variable and PSD tests | Difficult public failures remain; no exact/interval certificates |
| Industrial scale | Synthetic million-variable sparse box QP with known optimum | General million-variable LP/MILP/constrained QP and real industrial scale unproven |
| Recognized benchmarks | Netlib, historical MIPLIB, QPLIB, additional MIPLIB 2017 selection | Broader sets and Mittelmann runs; no full-library coverage |
| Established reference | HiGHS/OSQP, independent model parsing and original-solution checks | Repeat larger public workloads on final hardware; preserve incomplete references |
| Industrial use cases | Literature refinery planning/blending and transportation; synthetic multi-period production | MRPL data or domain-expert validation; operational deployment unproven |
| API/CLI | C++ APIs, MPS/QPLIB/lpmini CLI and JSON diagnostics | Stable ABI, broader format support and additional platform validation |
| Transparency | Phase records, source/input/binary hashes, reproduction scripts, notebook snapshot and audited Kaggle return bundle | Final report after remaining robustness/performance work; keep limitations visible |

Detailed implementation: `V2_ARCHITECTURE.md`. Current evidence:
`../reports/V2_REPORT.md`. Outstanding inputs: `V2_REMAINING.md`.
First GPU return: `../reports/KAGGLE_GPU_REPORT.md`.
