# Focused hard-MILP comparison

One sequential run per strategy/model, alternating order by model; equal time/node/gap limits. References after all timed runs. CPU only.

| Model | Strategy | Status | Objective | Gap | Verified candidate |
| --- | --- | --- | ---: | ---: | --- |
| blend2 | control | iteration_limit | None | None | False |
| blend2 | recovery_neighborhood | time_limit | None | None | False |

Generated correctness: True.

Experimental options are not promoted based on one timing pass. Limits and unresolved relaxations remain incomplete results, not infeasibility or optimality.

Inspect results.json, raw candidate/reference files, and incumbent_trace before choosing a default.
