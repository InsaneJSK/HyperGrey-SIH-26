# Focused hard-MILP comparison

One sequential run per strategy/model, alternating order by model; equal time/node/gap limits. References after all timed runs. CPU only.

| Model | Strategy | Status | Objective | Gap | Verified candidate |
| --- | --- | --- | ---: | ---: | --- |
| markshare_4_0 | control | time_limit | 7.999999999999979 | 0.8888888999999996 | True |
| markshare_4_0 | recovery_neighborhood | time_limit | 7.999999999999979 | 0.8888888999999996 | True |
| blend2 | recovery_neighborhood | numerical_error | None | None | False |
| blend2 | control | iteration_limit | None | None | False |
| binkar10_1 | control | time_limit | 7297.320029000008 | 0.08701811196246413 | True |
| binkar10_1 | recovery_neighborhood | time_limit | 6789.670034824617 | 0.018863779220001053 | True |

Generated correctness: True.

Experimental options are not promoted based on one timing pass. Limits and unresolved relaxations remain incomplete results, not infeasibility or optimality.

Inspect results.json, raw candidate/reference files, and incumbent_trace before choosing a default.
