# Focused hard-MILP comparison

One sequential run per strategy/model, alternating order by model; equal time/node/gap limits. References after all timed runs. CPU only.

| Model | Strategy | Status | Objective | Gap | Verified candidate |
| --- | --- | --- | ---: | ---: | --- |
| markshare_4_0 | control | time_limit | 20.999999975999998 | 0.9545454590413224 | True |
| markshare_4_0 | recovery_neighborhood | time_limit | 20.999999975999998 | 0.9545454590413224 | True |
| blend2 | recovery_neighborhood | time_limit | None | None | False |
| blend2 | control | time_limit | None | None | False |
| binkar10_1 | control | time_limit | 7297.320029000008 | 0.08801132890033811 | True |
| binkar10_1 | recovery_neighborhood | time_limit | 6810.690025698247 | 0.022929394363146158 | True |

Generated correctness: True.

Experimental options are not promoted based on one timing pass. Limits and unresolved relaxations remain incomplete results, not infeasibility or optimality.

Inspect results.json, raw candidate/reference files, and incumbent_trace before choosing a default.
