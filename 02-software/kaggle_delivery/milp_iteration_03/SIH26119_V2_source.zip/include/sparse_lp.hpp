#pragma once
#include "mps.hpp"
#include "sparse_lu.hpp"

namespace sovereign {
struct LpBasis { std::vector<std::size_t> columns; std::size_t structural_columns=0; };
struct SparseLpResult {
    Result solution;
    LpBasis basis;
    std::vector<double> canonical_primal, canonical_dual, row_dual;
    double best_bound=-std::numeric_limits<double>::infinity();
    bool warm_started=false;
    std::size_t factorizations=0;
};
SparseLpResult solve_sparse_lp(const LinearProblem&, const Options& = Options(), const LpBasis* = nullptr);
LinearProblem linear_from_dense(const Model&);
}
