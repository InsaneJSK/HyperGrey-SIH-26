# What is needed before final V2 submission

Deadline: 30 September 2026. The local implementation is a V2 candidate while
the remaining performance/robustness gaps are unresolved. The first GPU run
has been received and audited; see `../reports/KAGGLE_GPU_REPORT.md`.
The second return also confirms the MILP iteration on Kaggle/P100; see
`../reports/kaggle-gpu-02/REPORT.md`. No rerun of either unchanged notebook is needed.

The next bounded MILP cycle is recorded in `../reports/milp-iteration-01/REPORT.md`.
It adds a checked first incumbent on `binkar10_1`; this does not mean its gap
has closed. `blend2` and `markshare_4_0` remain explicit work items.
The [QP iteration](../reports/qp-iteration-01/REPORT.md) now gives QPLIB `9002`
an independently checked numerical optimum locally. Its reference-solver
comparison remains incomplete, and the new source still needs a Kaggle run.

1. **Next GPU evidence:** both returns passed all three CUDA scale cases
   and all 230 generated cases. Keep them as separate versioned evidence. After
   the next targeted iteration, collect repeated timings and public box-QP GPU
   checks. Memory diagnostics now show a solver-PID mismatch; process-attributed
   VRAM remains unresolved, although whole-device samples are available.
   The notebook must remain under 1 MB, with its source ZIP attached as input.
2. **Industrial relevance:** supply any MRPL-approved or shareable refinery,
   scheduling or supply-chain model, or domain-expert feedback on the literature
   case. Public teaching examples do not replace validation on actual operations.
3. **Organizer clarification:** confirm the acceptable QP scope (convex versus
   nonconvex) and use of GPU/general numerical infrastructure. No organizer
   approval has been obtained by this implementation work.
4. **Performance and robustness work:** validate the `9002` improvement on Kaggle,
   expand beyond this three-instance QP subset, and improve the incomplete modern
   MILPs. The original unscaled OSQP `9002` run still times out; preserve it and
   treat any future scaled-reference experiment as a separately labeled protocol.
   Small relative QP residuals are not promises of small absolute operational error.
5. **Final report:** the first bundle matches its source snapshot. Keep its
   observations labeled single-pass; repeat equal-accuracy measurements and finalize
   the PS requirement matrix and submission claims.

The PS's general ambition of reliable industrial-scale LP/MILP/QP up to millions
of variables is not established by a synthetic million-variable box QP. Complete
MIPLIB/Netlib/Mittelmann library coverage is not claimed. MIQP, NLP, MINLP and
global nonconvex QP are not implemented. Additional algorithms should be added
against explicit scope and test gates rather than counted as completed features.
