# Focused hard-MILP comparison

One sequential run per strategy/model, alternating order by model; equal time/node/gap limits. References after all timed runs. CPU only.

| Model | Strategy | Status | Objective | Gap | Verified candidate |
| --- | --- | --- | ---: | ---: | --- |
| markshare_4_0 | fractionality | time_limit | 20.999999975999998 | 0.9545454590413224 | True |
| markshare_4_0 | reliability | time_limit | 12.999999984 | 0.928571435632653 | True |
| blend2 | reliability | time_limit | None | None | False |
| blend2 | fractionality | time_limit | None | None | False |
| binkar10_1 | fractionality | time_limit | 7127.780038000008 | 0.0667233173706002 | True |
| binkar10_1 | reliability | time_limit | 7127.780038000008 | 0.06683245754145324 | True |

Generated correctness: True.

Experimental branching is not promoted based on one timing pass. Time/node limits are retained, not treated as infeasibility.

Inspect results.json, raw candidate/reference files, and incumbent_trace before choosing a default.
