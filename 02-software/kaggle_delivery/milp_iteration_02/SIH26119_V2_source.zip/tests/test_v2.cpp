#include "sparse_lp.hpp"
#include "accelerated_qp.hpp"
#include "milp.hpp"
#include <iostream>

void require(bool condition,const char* text){if(!condition)throw std::runtime_error(text);}
int main(){try{
    sovereign::SparseLU lu;
    std::vector<sovereign::SparseVector> columns={{{0,0},{1,2},{2,1}},{{0,1},{1,3}},{{0,2},{2,4}}};
    require(lu.factor(columns),"Sparse LU pivoting failed");
    auto x=lu.solve({8,8,13});
    require(std::abs(x[0]-1)<1e-10&&std::abs(x[1]-2)<1e-10&&std::abs(x[2]-3)<1e-10,"LU forward solve wrong");
    auto y=lu.solve({7,7,14},true);
    require(std::abs(y[0]-1)<1e-10&&std::abs(y[1]-2)<1e-10&&std::abs(y[2]-3)<1e-10,"LU transpose solve wrong");
    auto unbounded=sovereign::solve_sparse_lp(sovereign::linear_from_dense({{-1},{{-1}},{-2}}));
    require(unbounded.solution.status=="unbounded"&&unbounded.solution.unboundedness_verified&&unbounded.solution.unbounded_ray[0]>0,"Missing validated unbounded ray");
    sovereign::QuadraticProblem q;auto& p=q.linear;
    const std::size_t n=300;p.names.resize(n);p.cost.assign(n,-1);p.lower.assign(n,0);p.upper.assign(n,10);p.integer.assign(n,false);
    for(std::size_t j=0;j<n;++j){p.names[j]="x"+std::to_string(j);q.hessian.push_back({j,j,j%2?5.0:1.0});if(j%2)q.hessian.push_back({j,j-1,2.0});}
    require(sovereign::check_convex_hessian(q),"Large PSD non-diagonally-dominant Hessian rejected");
    sovereign::QpOptions options;options.time_limit=10;
    auto r=sovereign::solve_accelerated_box(q,options,false);
    require(r.status=="optimal"&&r.optimality_verified,"Large PSD box QP failed");
    q.hessian[0].value=-1;require(!sovereign::check_convex_hessian(q),"Indefinite Hessian accepted");
    sovereign::QuadraticProblem diagonal;auto& dp=diagonal.linear;
    dp.names={"a","b","c"};dp.cost={-4,-10,-20};dp.lower={0,0,0};dp.upper={10,10,10};dp.integer={false,false,false};
    dp.rows={{{0,1},{1,1},{2,1}}};dp.row_lower={6};dp.row_upper={6};diagonal.hessian={{0,0,2},{1,1,4},{2,2,6}};
    auto equality=sovereign::solve_qp_admm(diagonal);
    require(equality.status=="optimal"&&std::abs(equality.objective+48)<1e-6,"Diagonal equality QP failed");
    dp.lower[0]=dp.upper[0]=1;equality=sovereign::solve_qp_admm(diagonal);
    require(equality.status=="optimal"&&std::abs(equality.objective+48)<1e-6,"Fixed-variable diagonal QP failed");
    dp.maximize=true;for(double& v:dp.cost)v=-v;for(auto& h:diagonal.hessian)h.value=-h.value;
    equality=sovereign::solve_qp_admm(diagonal);require(equality.status=="optimal"&&std::abs(equality.objective-48)<1e-6,"Concave maximization QP normalization failed");
    require(std::isfinite(equality.dual_bound)&&equality.relative_gap<1e-7,"Diagonal maximization dual bound missing");
    require(std::abs(equality.dual_bound+48)<1e-6,"QP dual bound must use minimization sense");
    auto invalid=equality;invalid.primal[0]=NAN;sovereign::check_qp_solution(diagonal,invalid,1e-7);
    require(!invalid.optimality_verified,"Nonfinite candidate retained an optimality claim");
    invalid=equality;invalid.row_dual.clear();sovereign::check_qp_solution(diagonal,invalid,1e-7);
    require(!invalid.optimality_verified,"Malformed dual retained an optimality claim");
    // Structure-based routing above the former 512-variable limit; duplicated
    // rows deliberately make the dual Newton Schur system rank deficient.
    sovereign::QuadraticProblem big;auto& bp=big.linear;
    const std::size_t count=600;bp.names.resize(count);bp.cost.assign(count,0);bp.lower.assign(count,-INFINITY);bp.upper.assign(count,INFINITY);bp.integer.assign(count,false);
    for(std::size_t j=0;j<count;++j){bp.names[j]="z"+std::to_string(j);big.hessian.push_back({j,j,j%2?1e-12:1});}
    for(std::size_t j=0;j<count;j+=2){bp.rows.push_back({{j,1},{j+1,1e-6}});bp.row_lower.push_back(1e4);bp.row_upper.push_back(1e4);}
    bp.rows.push_back(bp.rows[0]);bp.row_lower.push_back(1e4);bp.row_upper.push_back(1e4);
    auto large=sovereign::solve_qp_admm(big);
    require(large.status=="optimal"&&large.algorithm=="diagonal_qp_dual_newton","Large structured QP dispatch failed");
    require(std::abs(large.objective-7.5e9)<750&&large.relative_gap<1e-7,"Large scaled QP objective/bound failed");
    bp.lower[0]=2;bp.upper[0]=1;large=sovereign::solve_qp_admm(big);
    require(large.status=="infeasible_bounds"&&!large.optimality_verified,"Invalid bounds reached the specialist");
    sovereign::QuadraticProblem flat;flat.linear.names={"flat","row"};flat.linear.cost={0,0};flat.linear.lower={-1e12,-1};flat.linear.upper={1e12,1};flat.linear.integer={false,false};
    flat.hessian={{0,0,1e-16},{1,1,1}};flat.linear.rows={{{1,1}}};flat.linear.row_lower={0};flat.linear.row_upper={0};
    sovereign::QpResult misleading;misleading.primal={1e8,0};misleading.row_dual={0};sovereign::check_qp_solution(flat,misleading,1e-7);
    require(misleading.stationarity_residual<1e-7&&misleading.relative_gap>.1&&!misleading.optimality_verified,"Tiny gradient bypassed the available diagonal dual-gap gate");
    sovereign::QuadraticProblem linear;linear.linear=sovereign::linear_from_dense({{-1e-12},{},{}});
    auto linear_qp=sovereign::solve_accelerated_box(linear,options,false);require(linear_qp.status=="unbounded","Zero-Hessian unbounded QP misclassified");
    bool rejected=false;try{options.threads=0;sovereign::solve_accelerated_box(q,options,false);}catch(const std::invalid_argument&){rejected=true;}
    require(rejected,"Invalid thread setting accepted");
    // General-integer interior targets require explicit absolute-distance columns.
    // With presolve disabled the root is fractional and rounding is infeasible;
    // the pump must project, detect a repeated target, perturb, and verify a repair.
    sovereign::LinearProblem pump_model;
    pump_model.names={"integer"};pump_model.cost={1};pump_model.lower={-3};pump_model.upper={3};pump_model.integer={true};
    pump_model.rows={{{0,1}}};pump_model.row_lower={1.25};pump_model.row_upper={INFINITY};
    sovereign::MilpOptions mo;mo.presolve=false;mo.cover_cuts=false;mo.node_limit=1;mo.lp.time_limit_seconds=10;
    auto pumped=sovereign::solve_milp(pump_model,mo);
    require(pumped.pump_projections>0&&pumped.pump_restarts>0&&pumped.pump_incumbents==1,"General-integer pump was not exercised");
    require(pumped.primal.size()==1&&pumped.primal[0]==2&&pumped.objective==2,"Pump produced an invalid integer repair");
    require(pumped.status=="node_limit"&&pumped.best_bound<=1.25&&pumped.gap>0,"Heuristic objective leaked into the proof bound");
    auto repeated=sovereign::solve_milp(pump_model,mo);
    require(repeated.primal==pumped.primal&&repeated.pump_projections==pumped.pump_projections,"Fixed-seed pump is not reproducible");
    pump_model.lower={.1};pump_model.upper={3.8};pumped=sovereign::solve_milp(pump_model,mo);
    require(pumped.primal.size()==1&&pumped.primal[0]==2,"Fractional bounds caused a nonintegral pump target");
    pump_model.lower={-3};pump_model.upper={3};
    pump_model.row_lower={-INFINITY};pump_model.row_upper={-1.25};pump_model.cost={1};pump_model.maximize=true;
    pumped=sovereign::solve_milp(pump_model,mo);
    require(pumped.primal.size()==1&&pumped.primal[0]==-2&&pumped.objective==-2&&pumped.best_bound>=-1.25,"Negative integer/maximization pump failed");
    pump_model.row_lower={.5};pump_model.row_upper={.5};pump_model.maximize=false;
    pumped=sovereign::solve_milp(pump_model,mo);
    require(pumped.primal.empty()&&pumped.pump_incumbents==0,"Infeasible rounded candidate was accepted");
    mo.feasibility_pump=false;pumped=sovereign::solve_milp(pump_model,mo);
    require(pumped.pump_projections==0&&pumped.pump_restarts==0,"Pump ablation flag ignored");
    mo.feasibility_pump=true;mo.heuristics=false;pumped=sovereign::solve_milp(pump_model,mo);
    require(pumped.pump_projections==0,"No-heuristics flag must disable the pump too");
    mo.lp.time_limit_seconds=0;pumped=sovereign::solve_milp(pump_model,mo);
    require(pumped.status=="time_limit"&&pumped.nodes==0&&pumped.primal.empty(),"Zero time budget was ignored");
    // Trial branch bounds and pseudocosts are selection information only.
    // The genuine root lower bound must survive a one-node search limit.
    pump_model.row_lower={1.25};pump_model.row_upper={INFINITY};pump_model.maximize=false;
    mo.lp.time_limit_seconds=5;mo.node_limit=1;mo.branching="reliability";
    auto branched=sovereign::solve_milp(pump_model,mo);
    require(branched.strong_branch_probes>0&&branched.pseudocost_updates>0,"Reliability branching was not exercised");
    require(branched.primal.size()==1&&branched.primal[0]==2&&branched.best_bound<=1.25&&branched.gap>0,"Trial branch estimate leaked into proof bound");
    require(branched.incumbent_trace.size()==1&&branched.incumbent_trace[0].second==2,"Incumbent trace did not record checked solution");
    mo.node_limit=100;branched=sovereign::solve_milp(pump_model,mo);
    require((branched.status=="optimal"||branched.status=="gap_limit")&&branched.objective==2,"Reliability general-integer solve failed");
    pump_model.row_lower={-INFINITY};pump_model.row_upper={-1.25};pump_model.maximize=true;
    branched=sovereign::solve_milp(pump_model,mo);
    require((branched.status=="optimal"||branched.status=="gap_limit")&&branched.objective==-2,"Reliability maximization sign failed");
    mo.branching="fractionality";branched=sovereign::solve_milp(pump_model,mo);
    require(branched.strong_branch_probes==0&&branched.pseudocost_updates==0,"Control branching mode changed");
    mo.branching="reliability";mo.lp.time_limit_seconds=0;branched=sovereign::solve_milp(pump_model,mo);
    require(branched.status=="time_limit"&&branched.strong_branch_probes==0,"Probe ignored zero solve budget");
    mo.branching="unknown";rejected=false;try{sovereign::solve_milp(pump_model,mo);}catch(const std::invalid_argument&){rejected=true;}
    require(rejected,"Invalid branching mode accepted");
    std::cout<<"V2 sparse LU, transpose, ray, extended PSD and option regressions passed\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
