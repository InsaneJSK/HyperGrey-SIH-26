#include "milp.hpp"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <queue>
#include <set>
#include <stdexcept>

namespace sovereign {
namespace {
const double inf=std::numeric_limits<double>::infinity();
struct Node {
    std::vector<double> lower,upper;
    double bound;
    std::size_t id,depth;
    LpBasis basis;
    std::size_t parent_variable;
    bool branch_up;
    double parent_lp_bound,branch_distance;
};
struct Order {
    bool operator()(const Node& a,const Node& b) const {
        if(a.bound!=b.bound)return a.bound>b.bound;
        if(a.depth!=b.depth)return a.depth<b.depth;
        return a.id>b.id;
    }
};
bool propagate(const LinearProblem& p,std::vector<double>& lo,std::vector<double>& up,std::size_t& changes) {
    for(std::size_t j=0;j<lo.size();++j) {
        if(p.integer[j]){lo[j]=std::ceil(lo[j]);up[j]=std::floor(up[j]);}
        if(lo[j]>up[j])return false;
    }
    for(int pass=0;pass<10;++pass) {
        bool changed=false;
        for(std::size_t i=0;i<p.rows.size();++i) {
            const auto& row=p.rows[i];
            long double minimum=0,maximum=0;int min_inf=0,max_inf=0;
            for(auto a:row) {
                if(a.second==0)continue;
                double low=a.second>0?lo[a.first]:up[a.first],high=a.second>0?up[a.first]:lo[a.first];
                if(std::isfinite(low))minimum+=static_cast<long double>(a.second)*low;else ++min_inf;
                if(std::isfinite(high))maximum+=static_cast<long double>(a.second)*high;else ++max_inf;
            }
            long double margin=1e-9L*(1+std::abs(minimum)+std::abs(maximum));
            if((!min_inf&&minimum>p.row_upper[i]+margin)||(!max_inf&&maximum<p.row_lower[i]-margin))return false;
            std::vector<std::pair<double,double> > proposed;
            for(auto a:row) {
                const std::size_t j=a.first;
                double low=a.second>0?lo[j]:up[j],high=a.second>0?up[j]:lo[j];
                double nl=lo[j],nu=up[j];
                auto tighten=[&](long double value,bool upper) {
                    double slack=1e-9*(1+std::abs(static_cast<double>(value)));
                    if(upper)nu=std::min(nu,static_cast<double>(value)+slack);else nl=std::max(nl,static_cast<double>(value)-slack);
                };
                if(a.second!=0&&std::isfinite(p.row_upper[i])&&min_inf-(!std::isfinite(low))==0) {
                    long double other=minimum-(std::isfinite(low)?static_cast<long double>(a.second)*low:0);
                    tighten((p.row_upper[i]-other)/a.second,a.second>0);
                }
                if(a.second!=0&&std::isfinite(p.row_lower[i])&&max_inf-(!std::isfinite(high))==0) {
                    long double other=maximum-(std::isfinite(high)?static_cast<long double>(a.second)*high:0);
                    tighten((p.row_lower[i]-other)/a.second,a.second<0);
                }
                if(p.integer[j]){nl=std::ceil(nl);nu=std::floor(nu);}
                if(nl>nu)return false;
                proposed.push_back({nl,nu});
            }
            // Apply together: all implied bounds were derived from the same row sums.
            for(std::size_t k=0;k<row.size();++k) {
                auto j=row[k].first;
                if(proposed[k].first>lo[j]+1e-10||proposed[k].second<up[j]-1e-10){changed=true;++changes;}
                lo[j]=proposed[k].first;up[j]=proposed[k].second;
            }
        }
        if(!changed)break;
    }
    return true;
}
std::size_t add_covers(LinearProblem& p,const std::vector<double>& x) {
    std::size_t added=0,original_rows=p.rows.size();
    for(std::size_t i=0;i<original_rows&&added<16;++i)for(int side=0;side<2&&added<16;++side) {
        double bound=side?p.row_lower[i]:p.row_upper[i],sign=side?-1:1;
        if(!std::isfinite(bound))continue;
        bound*=sign;
        struct Item {std::size_t j;double weight,z;bool complement;};std::vector<Item> items;bool valid=true;
        for(auto a:p.rows[i]) {
            if(a.second==0)continue;
            if(!p.integer[a.first]||p.lower[a.first]<0||p.upper[a.first]>1){valid=false;break;}
            double weight=sign*a.second;bool complement=weight<0;
            if(complement)bound-=weight;
            items.push_back({a.first,std::abs(weight),complement?1-x[a.first]:x[a.first],complement});
        }
        if(!valid||items.empty())continue;
        std::sort(items.begin(),items.end(),[](const Item& a,const Item& b){return a.z==b.z?a.weight>b.weight:a.z>b.z;});
        double sum=0,activity=0;std::size_t count=0;
        while(count<items.size()&&sum<=bound+1e-8*(1+std::abs(bound))) {sum+=items[count].weight;activity+=items[count].z;++count;}
        if(sum<=bound+1e-8*(1+std::abs(bound))||activity<=static_cast<double>(count)-1+1e-7)continue;
        SparseVector cut;double rhs=static_cast<double>(count)-1;
        for(std::size_t k=0;k<count;++k){cut.push_back({items[k].j,items[k].complement?-1.0:1.0});if(items[k].complement)rhs-=1;}
        std::sort(cut.begin(),cut.end());bool duplicate=false;
        for(std::size_t r=0;r<p.rows.size();++r)if(p.rows[r]==cut&&p.row_upper[r]==rhs)duplicate=true;
        if(!duplicate){p.rows.push_back(cut);p.row_lower.push_back(-inf);p.row_upper.push_back(rhs);++added;}
    }
    return added;
}
}
MilpResult solve_milp(const LinearProblem& original,const MilpOptions& opt) {
    validate_linear_problem(original);
    if(opt.integer_tolerance<=0||!std::isfinite(opt.integer_tolerance)||opt.relative_gap<0||!std::isfinite(opt.relative_gap))
        throw std::invalid_argument("Invalid MILP tolerances");
    if(opt.branching!="fractionality"&&opt.branching!="reliability")throw std::invalid_argument("MILP branching must be fractionality or reliability");
    MilpResult out;LinearProblem p=original;auto start=std::chrono::steady_clock::now();
    for(auto& row:p.rows){std::map<std::size_t,double> a;for(auto v:row)a[v.first]+=v.second;row.clear();for(auto v:a)if(v.second!=0)row.push_back(v);}
    double sign=p.maximize?-1:1,incumbent=inf;
    auto remaining=[&](){return std::max(0.0,opt.lp.time_limit_seconds-std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count());};
    auto accept=[&](std::vector<double> x) {
        if(x.size()!=p.cost.size())return false;
        for(double value:x)if(!std::isfinite(value))return false;
        for(std::size_t j=0;j<x.size();++j)if(p.integer[j]) {
            if(std::abs(x[j]-std::round(x[j]))>opt.integer_tolerance)return false;
            x[j]=std::round(x[j]);
        }
        if(original_violation(original,x,false)>1e-7)return false;
        double value=sign*p.offset;for(std::size_t j=0;j<x.size();++j)value+=sign*p.cost[j]*x[j];
        if(std::isfinite(value)&&value<incumbent){
            if(out.primal.empty())out.first_incumbent_seconds=opt.lp.time_limit_seconds-remaining();
            incumbent=value;out.primal=x;out.objective=sign*value;
            out.incumbent_trace.push_back({opt.lp.time_limit_seconds-remaining(),out.objective});
        }
        return std::isfinite(value);
    };
    auto relax=[&](const Node& node,bool heuristic,double budget) {
        const double stop=remaining()-std::min(remaining(),budget);
        LinearProblem model=p;model.lower=node.lower;model.upper=node.upper;
        std::fill(model.integer.begin(),model.integer.end(),false);
        Options o=opt.lp;o.time_limit_seconds=std::max(0.0,remaining()-stop);
        auto r=solve_sparse_lp(model,o,node.basis.columns.empty()?nullptr:&node.basis);
        if(r.solution.status=="numerical_error"||r.solution.status=="numerical_stall") {
            // Independent algorithmic recovery on small, difficult bases.
            try {
                auto standard=standardize(model,o.max_tableau_cells);o.time_limit_seconds=std::max(0.0,remaining()-stop);
                auto dense=solve(standard.model,o);out.lp_iterations+=r.solution.iterations;
                if(dense.status=="optimal"&&dense.optimality_verified) {
                    long double dual=0;for(std::size_t i=0;i<dense.dual.size();++i)dual+=standard.model.rhs[i]*dense.dual[i];
                    r.best_bound=static_cast<double>(dual)+sign*standard.objective_offset;
                    dense.primal=standard.recover(dense.primal);dense.objective=model.offset;
                    for(std::size_t j=0;j<dense.primal.size();++j)dense.objective+=model.cost[j]*dense.primal[j];
                    r.solution=dense;r.basis={};
                } else if(dense.status=="infeasible"&&dense.infeasibility_verified){r.solution=dense;r.basis={};}
            } catch(const std::runtime_error&) { /* Preserve the original failure if recovery exceeds its resource budget. */ }
        }
        out.lp_iterations+=r.solution.iterations;out.warm_starts+=r.warm_started;
        if(heuristic)++out.heuristic_solves;
        return r;
    };
    // Independently implemented L1 feasibility pump (Fischetti, Glover, Lodi).
    // These LP objectives are distances, NEVER valid objective bounds for the tree.
    auto pump=[&](const Node& node,const std::vector<double>& initial) {
        const double stop=std::max(0.0,remaining()-5.0);
        const std::size_t n=p.cost.size();
        auto px=initial;
        const std::size_t no_aux=std::numeric_limits<std::size_t>::max();
        std::vector<std::size_t> integers,aux(n,no_aux);
        LinearProblem projection=p;
        projection.lower=node.lower;projection.upper=node.upper;
        projection.maximize=false;projection.offset=0;
        std::fill(projection.integer.begin(),projection.integer.end(),false);
        std::fill(projection.cost.begin(),projection.cost.end(),0);
        for(std::size_t j=0;j<n;++j)if(p.integer[j]&&node.lower[j]<node.upper[j]) {
            integers.push_back(j);
            // Keep general-integer distance columns and rows structurally stable
            // between iterations, so basis reuse remains safe when targets change.
            if(node.upper[j]-node.lower[j]>1) {
                aux[j]=projection.cost.size();
                projection.names.push_back("pump_distance_"+std::to_string(j));
                projection.cost.push_back(1);projection.lower.push_back(0);
                projection.upper.push_back(inf);projection.integer.push_back(false);
                projection.rows.push_back({{j,1},{aux[j],-1}});
                projection.rows.push_back({{j,-1},{aux[j],-1}});
                projection.row_lower.push_back(-inf);projection.row_lower.push_back(-inf);
                projection.row_upper.push_back(0);projection.row_upper.push_back(0);
            }
        }
        if(integers.empty())return;
        LpBasis basis=projection.cost.size()==n?node.basis:LpBasis{};
        std::set<std::vector<double> > visited;
        std::uint32_t rng=26119;
        auto random=[&](){rng=1664525u*rng+1013904223u;return double(rng)/4294967296.0;};
        for(int iteration=0;iteration<40&&remaining()>stop;++iteration) {
            std::vector<double> target(n,0),key;
            for(std::size_t j=0;j<n;++j)if(p.integer[j])
                target[j]=std::max(std::ceil(node.lower[j]),std::min(std::floor(node.upper[j]),std::round(px[j])));
            for(auto j:integers)key.push_back(target[j]);
            if(visited.count(key)) {
                ++out.pump_restarts;
                std::vector<std::pair<double,std::size_t> > order;
                for(auto j:integers)order.push_back({std::abs(px[j]-target[j])+.35*random(),j});
                std::sort(order.rbegin(),order.rend());
                const std::size_t flips=std::min(order.size(),1+out.pump_restarts%8);
                for(std::size_t k=0;k<flips;++k) {
                    auto j=order[k].second;
                    double direction=px[j]>target[j]?1:(px[j]<target[j]?-1:(random()<.5?-1:1));
                    double value=target[j]+direction;
                    if(value<node.lower[j]||value>node.upper[j])value=target[j]-direction;
                    target[j]=std::max(std::ceil(node.lower[j]),std::min(std::floor(node.upper[j]),value));
                }
                key.clear();for(auto j:integers)key.push_back(target[j]);
            }
            visited.insert(key);
            // Optimize continuous variables with exact integer fixings. Propagation
            // can reject a rounded target cheaply, but can never certify feasibility.
            Node fixed=node;
            for(std::size_t j=0;j<n;++j)if(p.integer[j])fixed.lower[j]=fixed.upper[j]=target[j];
            if((!opt.presolve||propagate(p,fixed.lower,fixed.upper,out.bound_tightenings))&&remaining()>stop) {
                LinearProblem polished=p;polished.lower=fixed.lower;polished.upper=fixed.upper;
                std::fill(polished.integer.begin(),polished.integer.end(),false);
                Options o=opt.lp;o.tolerance=std::min(o.tolerance,1e-11);
                o.time_limit_seconds=std::max(0.0,remaining()-stop);
                auto r=solve_sparse_lp(polished,o);
                ++out.heuristic_solves;out.lp_iterations+=r.solution.iterations;
                double previous=incumbent;
                if(accept(r.solution.primal)) {
                    if(incumbent<previous)++out.pump_incumbents;
                    return;
                }
            }
            std::size_t row=p.rows.size();
            for(auto j:integers) {
                if(aux[j]!=no_aux) {
                    projection.row_upper[row++]=target[j];
                    projection.row_upper[row++]=-target[j];
                } else projection.cost[j]=target[j]==node.lower[j]?1:-1;
            }
            Options o=opt.lp;o.time_limit_seconds=std::max(0.0,remaining()-stop);
            if(o.time_limit_seconds<=0)break;
            auto r=solve_sparse_lp(projection,o,basis.columns.empty()?nullptr:&basis);
            ++out.pump_projections;++out.heuristic_solves;out.lp_iterations+=r.solution.iterations;
            out.warm_starts+=r.warm_started;
            if(r.solution.status!="optimal"||!r.solution.optimality_verified)break;
            basis=r.basis;px=r.solution.primal;px.resize(n);
            double previous=incumbent;
            if(accept(px)) {if(incumbent<previous)++out.pump_incumbents;return;}
        }
    };
    struct Pseudo {double sum[2]={0,0};std::size_t count[2]={0,0};};
    std::vector<Pseudo> pseudo(p.cost.size());double pseudo_total=0;std::size_t pseudo_count=0;
    auto learn=[&](std::size_t j,bool up,double distance,double child,double parent) {
        if(distance<=opt.integer_tolerance||!std::isfinite(child)||!std::isfinite(parent))return;
        double value=std::max(0.0,child-parent)/distance;
        if(!std::isfinite(value))return;
        pseudo[j].sum[up]+=value;++pseudo[j].count[up];pseudo_total+=value;++pseudo_count;++out.pseudocost_updates;
    };
    auto choose_branch=[&](const Node& node,const std::vector<double>& x,double parent_bound) {
        struct Candidate {std::size_t j;double score,down,up;};std::vector<Candidate> candidates;
        const double average=pseudo_count?std::max(1e-8,pseudo_total/pseudo_count):1;
        auto score=[](double down,double up){return .9*std::min(down,up)+.1*std::max(down,up);};
        for(std::size_t j=0;j<x.size();++j)if(p.integer[j]) {
            double fraction=x[j]-std::floor(x[j]);if(std::min(fraction,1-fraction)<=opt.integer_tolerance)continue;
            double down=fraction*(pseudo[j].count[0]?pseudo[j].sum[0]/pseudo[j].count[0]:average);
            double up=(1-fraction)*(pseudo[j].count[1]?pseudo[j].sum[1]/pseudo[j].count[1]:average);
            candidates.push_back({j,score(down,up),down,up});
        }
        if(candidates.empty())return p.cost.size();
        std::sort(candidates.begin(),candidates.end(),[](const Candidate& a,const Candidate& b){return a.score==b.score?a.j<b.j:a.score>b.score;});
        // Trial LPs only inform branch selection. Their estimates NEVER replace
        // tree proof bounds, prune a branch, or manufacture an incumbent.
        double allowance=std::min(15.0,.15*opt.lp.time_limit_seconds)-out.strong_branch_seconds;
        double budget=std::max(0.0,std::min(allowance,std::min(node.depth==0?2.0:.5,.1*remaining())));
        auto begin=std::chrono::steady_clock::now();
        auto probe_left=[&](){return std::max(0.0,std::min(remaining(),budget-std::chrono::duration<double>(std::chrono::steady_clock::now()-begin).count()));};
        for(std::size_t k=0;k<std::min<std::size_t>(4,candidates.size())&&probe_left()>0&&out.strong_branch_probes<128;++k) {
            auto& candidate=candidates[k];auto j=candidate.j;
            for(int side=0;side<2&&probe_left()>0&&out.strong_branch_probes<128;++side) {
                if(pseudo[j].count[side]>=2)continue;
                Node trial=node;double distance=side?std::ceil(x[j])-x[j]:x[j]-std::floor(x[j]);
                if(side)trial.lower[j]=std::ceil(x[j]);else trial.upper[j]=std::floor(x[j]);
                double gain=side?candidate.up:candidate.down;
                if(opt.presolve&&!propagate(p,trial.lower,trial.upper,out.bound_tightenings))gain=1e30;
                else {
                    LinearProblem model=p;model.lower=trial.lower;model.upper=trial.upper;std::fill(model.integer.begin(),model.integer.end(),false);
                    Options o=opt.lp;o.time_limit_seconds=std::min(.5,probe_left());o.iteration_limit=std::min<std::size_t>(250,o.iteration_limit);
                    auto solved=solve_sparse_lp(model,o,trial.basis.columns.empty()?nullptr:&trial.basis);
                    ++out.strong_branch_probes;out.lp_iterations+=solved.solution.iterations;out.warm_starts+=solved.warm_started;
                    if(solved.solution.status=="optimal"&&solved.solution.optimality_verified) {
                        learn(j,side!=0,distance,solved.best_bound,parent_bound);gain=std::max(0.0,solved.best_bound-parent_bound);
                        accept(solved.solution.primal);
                    } else if(solved.solution.status=="infeasible"&&solved.solution.infeasibility_verified)gain=1e30;
                }
                if(side)candidate.up=gain;else candidate.down=gain;
            }
            candidate.score=score(candidate.down,candidate.up);
        }
        out.strong_branch_seconds+=std::chrono::duration<double>(std::chrono::steady_clock::now()-begin).count();
        return std::max_element(candidates.begin(),candidates.end(),[](const Candidate& a,const Candidate& b){return a.score==b.score?a.j>b.j:a.score<b.score;})->j;
    };
    std::priority_queue<Node,std::vector<Node>,Order> queue;
    Node root={p.lower,p.upper,-inf,0,0,{},0,false,0,0};queue.push(root);std::size_t serial=1;
    out.status="optimal";
    while(!queue.empty()) {
        if(remaining()<=0){out.status="time_limit";break;}
        if(out.nodes>=opt.node_limit){out.status="node_limit";break;}
        if(std::isfinite(incumbent)&&queue.top().bound>=incumbent-opt.relative_gap*(1+std::abs(incumbent))){out.status="gap_limit";break;}
        Node node=queue.top();queue.pop();++out.nodes;
        if(opt.presolve&&!propagate(p,node.lower,node.upper,out.bound_tightenings))continue;
        auto lp=relax(node,false,remaining());
        if(lp.solution.status=="infeasible"&&lp.solution.infeasibility_verified)continue;
        if(lp.solution.status!="optimal"||!lp.solution.optimality_verified) {
            queue.push(node);out.status=lp.solution.status=="unbounded"?"unbounded_relaxation":lp.solution.status;
            out.message="LP relaxation did not pass its numerical checks";break;
        }
        if(opt.branching=="reliability"&&node.depth>0)learn(node.parent_variable,node.branch_up,node.branch_distance,lp.best_bound,node.parent_lp_bound);
        node.basis=lp.basis;node.bound=std::max(node.bound,lp.best_bound-100*opt.lp.tolerance*(1+std::abs(lp.best_bound)));
        if(node.depth==0&&opt.cover_cuts) {
            // Reserve a full pump allowance. Repeated root cut solves must not
            // shrink the first-incumbent search to a fraction of the last second.
            const double cut_stop=opt.heuristics&&opt.feasibility_pump?std::min(5.0,remaining()):0;
            for(int pass=0;pass<5&&remaining()>cut_stop;++pass) {
                const std::size_t old_rows=p.rows.size();
                auto added=add_covers(p,lp.solution.primal);out.cuts+=added;if(!added)break;
                auto previous=lp;
                node.basis={};lp=relax(node,false,std::max(0.0,remaining()-cut_stop));
                if(lp.solution.status=="infeasible"&&lp.solution.infeasibility_verified&&out.primal.empty())break;
                if(lp.solution.status!="optimal"||!lp.solution.optimality_verified) {
                    // A cut attempt is optional. If its LP misses the budget/checks,
                    // restore both model and validated pre-cut basis/relaxation.
                    p.rows.resize(old_rows);p.row_lower.resize(old_rows);p.row_upper.resize(old_rows);
                    out.cuts-=added;++out.cut_rollbacks;lp=std::move(previous);node.basis=lp.basis;
                    break;
                }
            }
            if(lp.solution.status=="infeasible"&&lp.solution.infeasibility_verified)continue;
            if(lp.solution.status!="optimal"||!lp.solution.optimality_verified){queue.push(node);out.status=lp.solution.status;break;}
        }
        node.basis=lp.basis;node.bound=std::max(node.bound,lp.best_bound-100*opt.lp.tolerance*(1+std::abs(lp.best_bound)));
        if(node.bound>=incumbent)continue;
        auto x=lp.solution.primal;accept(x);
        if(opt.heuristics&&opt.feasibility_pump&&node.depth==0&&out.primal.empty())pump(node,x);
        if(opt.heuristics&&(out.nodes==1||(out.primal.empty()&&out.nodes%100==0))) {
            double budget=std::min(2.0,remaining()*.2),until=remaining()-budget;
            for(int mode=0;mode<2&&remaining()>until;++mode) {
                Node dive=node;auto dx=x;
                for(std::size_t step=0;step<64&&remaining()>until;++step) {
                    std::size_t branch=p.cost.size();double fraction=opt.integer_tolerance;
                    for(std::size_t j=0;j<dx.size();++j)if(p.integer[j]&&std::abs(dx[j]-std::round(dx[j]))>fraction) {
                        branch=j;fraction=std::abs(dx[j]-std::round(dx[j]));
                    }
                    if(branch==p.cost.size()){accept(dx);break;}
                    bool up=mode?sign*p.cost[branch]<0:dx[branch]-std::floor(dx[branch])>=.5;
                    Node alternate=dive;
                    if(up){dive.lower[branch]=std::ceil(dx[branch]);alternate.upper[branch]=std::floor(dx[branch]);}
                    else {dive.upper[branch]=std::floor(dx[branch]);alternate.lower[branch]=std::ceil(dx[branch]);}
                    auto attempt=[&](Node& d){if(remaining()<=until||(opt.presolve&&!propagate(p,d.lower,d.upper,out.bound_tightenings))){SparseLpResult bad;bad.solution.status="infeasible";return bad;}return relax(d,true,std::max(0.0,remaining()-until));};
                    auto trial=attempt(dive);
                    if(trial.solution.status!="optimal"){dive=alternate;trial=attempt(dive);}
                    if(trial.solution.status!="optimal"||!trial.solution.optimality_verified)break;
                    dive.basis=trial.basis;dx=trial.solution.primal;accept(dx);
                }
            }
        }
        std::size_t branch=p.cost.size();double score=opt.integer_tolerance;
        for(std::size_t j=0;j<x.size();++j)if(p.integer[j]) {
            double fractional=std::abs(x[j]-std::round(x[j]));
            if(fractional>score){score=fractional;branch=j;}
        }
        if(branch!=p.cost.size()&&opt.branching=="reliability")branch=choose_branch(node,x,lp.best_bound);
        if(branch==p.cost.size()) {
            if(!accept(x)) {
                LinearProblem fixed=original;
                for(std::size_t j=0;j<x.size();++j)if(p.integer[j])fixed.lower[j]=fixed.upper[j]=std::round(x[j]);
                std::fill(fixed.integer.begin(),fixed.integer.end(),false);
                Options polish_options=opt.lp;polish_options.tolerance=std::min(1e-11,opt.lp.tolerance);polish_options.time_limit_seconds=remaining();
                auto polished=solve_sparse_lp(fixed,polish_options);out.lp_iterations+=polished.solution.iterations;++out.heuristic_solves;
                if(polished.solution.status=="optimal"&&accept(polished.solution.primal))continue;
                for(std::size_t j=0;j<x.size();++j)if(p.integer[j])x[j]=std::round(x[j]);
                queue.push(node);out.status="numerical_error";
                out.message="Rounded integer candidate violation "+std::to_string(original_violation(original,x,false));break;
            }
            continue;
        }
        Node down=node,up=node;down.upper[branch]=std::floor(x[branch]);up.lower[branch]=std::ceil(x[branch]);
        down.parent_variable=up.parent_variable=branch;down.branch_up=false;up.branch_up=true;
        down.parent_lp_bound=up.parent_lp_bound=lp.best_bound;
        down.branch_distance=x[branch]-std::floor(x[branch]);up.branch_distance=std::ceil(x[branch])-x[branch];
        down.depth=up.depth=node.depth+1;down.id=serial++;up.id=serial++;
        if(down.lower[branch]<=down.upper[branch])queue.push(std::move(down));
        if(up.lower[branch]<=up.upper[branch])queue.push(std::move(up));
    }
    if(queue.empty()) {
        if(out.primal.empty())out.status="infeasible";
        out.best_bound=out.primal.empty()?sign*inf:out.objective;out.gap=out.primal.empty()?inf:0;
    } else {
        double bound=std::min(queue.top().bound,incumbent);out.best_bound=sign*bound;
        if(std::isfinite(incumbent)&&std::isfinite(bound))out.gap=std::max(0.0,incumbent-bound)/(1+std::abs(incumbent));
    }
    return out;
}
}
