# What is needed before final V2 submission

Deadline: 30 September 2026. The local implementation is a V2 candidate while
the remaining performance/robustness gaps are unresolved. The first GPU run
has been received and audited; see `../reports/KAGGLE_GPU_REPORT.md`.

The next bounded MILP cycle is recorded in `../reports/milp-iteration-01/REPORT.md`.
It adds a checked first incumbent on `binkar10_1`; this does not mean its gap
has closed. `blend2`, `markshare_4_0`, and constrained QPLIB `9002` remain
explicit work items. Constrained-QP changes are reserved for the next cycle.

1. **Next GPU evidence:** the first return passed all three CUDA scale cases
   and all 230 generated cases. Keep it as the baseline. After the next
   targeted iteration, collect repeated timings, public box-QP GPU checks and
   improved memory diagnostics. There is no need to resend the same first ZIP.
   The notebook must remain under 1 MB, with its source ZIP attached as input.
2. **Industrial relevance:** supply any MRPL-approved or shareable refinery,
   scheduling or supply-chain model, or domain-expert feedback on the literature
   case. Public teaching examples do not replace validation on actual operations.
3. **Organizer clarification:** confirm the acceptable QP scope (convex versus
   nonconvex) and use of GPU/general numerical infrastructure. No organizer
   approval has been obtained by this implementation work.
4. **Performance and robustness work:** preserve and improve constrained QPLIB
   `9002` and incomplete modern MIPLIB instances. An incomplete solve remains
   incomplete even if its candidate objective looks promising.
5. **Final report:** the first bundle matches its source snapshot. Keep its
   observations labeled single-pass; repeat equal-accuracy measurements and finalize
   the PS requirement matrix and submission claims.

The PS's general ambition of reliable industrial-scale LP/MILP/QP up to millions
of variables is not established by a synthetic million-variable box QP. Complete
MIPLIB/Netlib/Mittelmann library coverage is not claimed. MIQP, NLP, MINLP and
global nonconvex QP are not implemented. Additional algorithms should be added
against explicit scope and test gates rather than counted as completed features.
