#pragma once
#include "mps.hpp"
#include "sparse_lp.hpp"

namespace sovereign {
struct MilpOptions {
    Options lp;
    std::size_t node_limit = 10000;
    double integer_tolerance = 1e-7;
    double relative_gap = 1e-6;
    bool presolve = true;
    bool heuristics = true;
    bool feasibility_pump = true;
    bool cover_cuts = true;
};
struct MilpResult {
    std::string status;
    std::vector<double> primal;
    double objective = std::numeric_limits<double>::quiet_NaN();
    double best_bound = -std::numeric_limits<double>::infinity();
    double gap = std::numeric_limits<double>::infinity();
    std::size_t nodes = 0;
    std::size_t lp_iterations = 0;
    std::size_t warm_starts = 0, heuristic_solves = 0, cuts = 0, bound_tightenings = 0;
    std::size_t pump_projections = 0, pump_restarts = 0, pump_incumbents = 0;
    std::size_t cut_rollbacks = 0;
    double first_incumbent_seconds = std::numeric_limits<double>::quiet_NaN();
    std::string message;
};
MilpResult solve_milp(const LinearProblem&, const MilpOptions& = MilpOptions());
}
