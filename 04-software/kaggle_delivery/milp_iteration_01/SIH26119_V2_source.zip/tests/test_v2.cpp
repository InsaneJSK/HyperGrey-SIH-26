#include "sparse_lp.hpp"
#include "accelerated_qp.hpp"
#include "milp.hpp"
#include <iostream>

void require(bool condition,const char* text){if(!condition)throw std::runtime_error(text);}
int main(){try{
    sovereign::SparseLU lu;
    std::vector<sovereign::SparseVector> columns={{{0,0},{1,2},{2,1}},{{0,1},{1,3}},{{0,2},{2,4}}};
    require(lu.factor(columns),"Sparse LU pivoting failed");
    auto x=lu.solve({8,8,13});
    require(std::abs(x[0]-1)<1e-10&&std::abs(x[1]-2)<1e-10&&std::abs(x[2]-3)<1e-10,"LU forward solve wrong");
    auto y=lu.solve({7,7,14},true);
    require(std::abs(y[0]-1)<1e-10&&std::abs(y[1]-2)<1e-10&&std::abs(y[2]-3)<1e-10,"LU transpose solve wrong");
    auto unbounded=sovereign::solve_sparse_lp(sovereign::linear_from_dense({{-1},{{-1}},{-2}}));
    require(unbounded.solution.status=="unbounded"&&unbounded.solution.unboundedness_verified&&unbounded.solution.unbounded_ray[0]>0,"Missing validated unbounded ray");
    sovereign::QuadraticProblem q;auto& p=q.linear;
    const std::size_t n=300;p.names.resize(n);p.cost.assign(n,-1);p.lower.assign(n,0);p.upper.assign(n,10);p.integer.assign(n,false);
    for(std::size_t j=0;j<n;++j){p.names[j]="x"+std::to_string(j);q.hessian.push_back({j,j,j%2?5.0:1.0});if(j%2)q.hessian.push_back({j,j-1,2.0});}
    require(sovereign::check_convex_hessian(q),"Large PSD non-diagonally-dominant Hessian rejected");
    sovereign::QpOptions options;options.time_limit=10;
    auto r=sovereign::solve_accelerated_box(q,options,false);
    require(r.status=="optimal"&&r.optimality_verified,"Large PSD box QP failed");
    q.hessian[0].value=-1;require(!sovereign::check_convex_hessian(q),"Indefinite Hessian accepted");
    sovereign::QuadraticProblem diagonal;auto& dp=diagonal.linear;
    dp.names={"a","b","c"};dp.cost={-4,-10,-20};dp.lower={0,0,0};dp.upper={10,10,10};dp.integer={false,false,false};
    dp.rows={{{0,1},{1,1},{2,1}}};dp.row_lower={6};dp.row_upper={6};diagonal.hessian={{0,0,2},{1,1,4},{2,2,6}};
    auto equality=sovereign::solve_qp_admm(diagonal);
    require(equality.status=="optimal"&&std::abs(equality.objective+48)<1e-6,"Diagonal equality QP failed");
    dp.lower[0]=dp.upper[0]=1;equality=sovereign::solve_qp_admm(diagonal);
    require(equality.status=="optimal"&&std::abs(equality.objective+48)<1e-6,"Fixed-variable diagonal QP failed");
    dp.maximize=true;for(double& v:dp.cost)v=-v;for(auto& h:diagonal.hessian)h.value=-h.value;
    equality=sovereign::solve_qp_admm(diagonal);require(equality.status=="optimal"&&std::abs(equality.objective-48)<1e-6,"Concave maximization QP normalization failed");
    sovereign::QuadraticProblem linear;linear.linear=sovereign::linear_from_dense({{-1e-12},{},{}});
    auto linear_qp=sovereign::solve_accelerated_box(linear,options,false);require(linear_qp.status=="unbounded","Zero-Hessian unbounded QP misclassified");
    bool rejected=false;try{options.threads=0;sovereign::solve_accelerated_box(q,options,false);}catch(const std::invalid_argument&){rejected=true;}
    require(rejected,"Invalid thread setting accepted");
    // General-integer interior targets require explicit absolute-distance columns.
    // With presolve disabled the root is fractional and rounding is infeasible;
    // the pump must project, detect a repeated target, perturb, and verify a repair.
    sovereign::LinearProblem pump_model;
    pump_model.names={"integer"};pump_model.cost={1};pump_model.lower={-3};pump_model.upper={3};pump_model.integer={true};
    pump_model.rows={{{0,1}}};pump_model.row_lower={1.25};pump_model.row_upper={INFINITY};
    sovereign::MilpOptions mo;mo.presolve=false;mo.cover_cuts=false;mo.node_limit=1;mo.lp.time_limit_seconds=10;
    auto pumped=sovereign::solve_milp(pump_model,mo);
    require(pumped.pump_projections>0&&pumped.pump_restarts>0&&pumped.pump_incumbents==1,"General-integer pump was not exercised");
    require(pumped.primal.size()==1&&pumped.primal[0]==2&&pumped.objective==2,"Pump produced an invalid integer repair");
    require(pumped.status=="node_limit"&&pumped.best_bound<=1.25&&pumped.gap>0,"Heuristic objective leaked into the proof bound");
    auto repeated=sovereign::solve_milp(pump_model,mo);
    require(repeated.primal==pumped.primal&&repeated.pump_projections==pumped.pump_projections,"Fixed-seed pump is not reproducible");
    pump_model.lower={.1};pump_model.upper={3.8};pumped=sovereign::solve_milp(pump_model,mo);
    require(pumped.primal.size()==1&&pumped.primal[0]==2,"Fractional bounds caused a nonintegral pump target");
    pump_model.lower={-3};pump_model.upper={3};
    pump_model.row_lower={-INFINITY};pump_model.row_upper={-1.25};pump_model.cost={1};pump_model.maximize=true;
    pumped=sovereign::solve_milp(pump_model,mo);
    require(pumped.primal.size()==1&&pumped.primal[0]==-2&&pumped.objective==-2&&pumped.best_bound>=-1.25,"Negative integer/maximization pump failed");
    pump_model.row_lower={.5};pump_model.row_upper={.5};pump_model.maximize=false;
    pumped=sovereign::solve_milp(pump_model,mo);
    require(pumped.primal.empty()&&pumped.pump_incumbents==0,"Infeasible rounded candidate was accepted");
    mo.feasibility_pump=false;pumped=sovereign::solve_milp(pump_model,mo);
    require(pumped.pump_projections==0&&pumped.pump_restarts==0,"Pump ablation flag ignored");
    mo.feasibility_pump=true;mo.heuristics=false;pumped=sovereign::solve_milp(pump_model,mo);
    require(pumped.pump_projections==0,"No-heuristics flag must disable the pump too");
    mo.lp.time_limit_seconds=0;pumped=sovereign::solve_milp(pump_model,mo);
    require(pumped.status=="time_limit"&&pumped.nodes==0&&pumped.primal.empty(),"Zero time budget was ignored");
    std::cout<<"V2 sparse LU, transpose, ray, extended PSD and option regressions passed\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
