#include "solver.hpp"
#include "mps.hpp"
#include "milp.hpp"
#include "qp.hpp"
#include "sparse_lp.hpp"
#include "accelerated_qp.hpp"
#include <chrono>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <cmath>

namespace {
double number_option(const char* text){std::size_t used=0;double value=std::stod(text,&used);if(used!=std::string(text).size()||!std::isfinite(value))throw std::invalid_argument("Expected a finite numeric option");return value;}
std::size_t count_option(const char* text){double value=number_option(text);if(value<0||value>100000000||std::floor(value)!=value)throw std::invalid_argument("Expected an integer option in [0,100000000]");return static_cast<std::size_t>(value);}
void numeric(double v) { if (std::isfinite(v)) std::cout << v; else std::cout << "null"; }
void array(const std::vector<double>& v) {
    std::cout << '[';
    for (std::size_t i = 0; i < v.size(); ++i) { if (i) std::cout << ','; numeric(v[i]); }
    std::cout << ']';
}
void lp_failure(const sovereign::MilpLpFailure& f) {
    if(f.status.empty()){std::cout<<"null";return;}
    std::cout<<"{\"status\":\""<<f.status<<"\",\"captured\":"<<(f.captured?"true":"false")<<",\"node\":"<<f.node<<",\"depth\":"<<f.depth<<",\"iterations\":"<<f.iterations<<",\"parent_bound_minimization_sense\":";numeric(f.parent_bound);
    if(f.captured){
        const auto& p=f.model;
        std::cout<<",\"maximize\":"<<(p.maximize?"true":"false")<<",\"offset\":";numeric(p.offset);
        std::cout<<",\"cost\":";array(p.cost);std::cout<<",\"lower\":";array(p.lower);std::cout<<",\"upper\":";array(p.upper);
        std::cout<<",\"row_lower\":";array(p.row_lower);std::cout<<",\"row_upper\":";array(p.row_upper);
        std::cout<<",\"rows\":[";
        for(std::size_t i=0;i<p.rows.size();++i){if(i)std::cout<<',';std::cout<<'[';for(std::size_t k=0;k<p.rows[i].size();++k){if(k)std::cout<<',';std::cout<<'['<<p.rows[i][k].first<<',';numeric(p.rows[i][k].second);std::cout<<']';}std::cout<<']';}
        std::cout<<"],\"basis_structural_columns\":"<<f.input_basis.structural_columns<<",\"input_basis_columns\":[";
        for(std::size_t k=0;k<f.input_basis.columns.size();++k){if(k)std::cout<<',';std::cout<<f.input_basis.columns[k];}std::cout<<']';
    }
    std::cout<<'}';
}
}

int main(int argc, char** argv) {
    if(argc==2&&std::string(argv[1])=="--version"){std::cout<<"Sovereign SIH26119 V2 candidate; C++ core, sparse simplex, branch-and-cut, convex QP\n";return 0;}
    if (argc < 2) { std::cerr << "Usage: solver_cli MODEL.{lpmini,mps} [--json] [--no-scaling] [--time-limit seconds]\n"; return 2; }
    try {
        bool json = false;
        bool milp = false;
        std::string lp_method="sparse";
        int threads=1;
        std::string backend="cpu";
        bool custom_iterations=false,custom_tolerance=false;
        sovereign::MilpOptions mip_options;
        sovereign::Options options;
        for (int i = 2; i < argc; ++i) {
            std::string arg = argv[i];
            if (arg == "--json") json = true;
            else if (arg == "--milp") milp = true;
            else if (arg == "--no-scaling") options.scaling = false;
            else if (arg == "--lp-method" && i+1<argc) lp_method=argv[++i];
            else if (arg == "--iteration-limit" && i+1<argc) {options.iteration_limit=count_option(argv[++i]);custom_iterations=true;}
            else if (arg == "--tolerance" && i+1<argc) {options.tolerance=number_option(argv[++i]);custom_tolerance=true;}
            else if (arg == "--threads" && i+1<argc) threads=static_cast<int>(count_option(argv[++i]));
            else if (arg == "--backend" && i+1<argc) backend=argv[++i];
            else if (arg == "--node-limit" && i+1<argc) mip_options.node_limit=count_option(argv[++i]);
            else if (arg == "--no-presolve") mip_options.presolve=false;
            else if (arg == "--no-heuristics") mip_options.heuristics=false;
            else if (arg == "--no-pump") mip_options.feasibility_pump=false;
            else if (arg == "--no-cuts") mip_options.cover_cuts=false;
            else if (arg == "--branching" && i+1<argc) mip_options.branching=argv[++i];
            else if (arg == "--lp-recovery") mip_options.lp_recovery=true;
            else if (arg == "--improve-incumbent") mip_options.improve_incumbent=true;
            else if (arg == "--capture-lp-failure") mip_options.capture_lp_failure=true;
            else if (arg == "--capture-rejected-candidates") mip_options.capture_rejected_candidates=true;
            else if (arg == "--repair-candidates") mip_options.repair_candidates=true;
            else if (arg == "--gap" && i+1<argc) mip_options.relative_gap=number_option(argv[++i]);
            else if (arg == "--time-limit" && i + 1 < argc) options.time_limit_seconds = number_option(argv[++i]);
            else throw std::runtime_error("Unknown or incomplete option: " + arg);
        }
        if(lp_method!="sparse"&&lp_method!="dense")throw std::runtime_error("LP method must be sparse or dense");
        if(backend!="cpu"&&backend!="cuda")throw std::runtime_error("Backend must be cpu or cuda");
        if(threads<1||threads>256)throw std::runtime_error("Threads must be between 1 and 256");
        if(options.tolerance<=0||options.time_limit_seconds<0||mip_options.relative_gap<0)throw std::runtime_error("Tolerance must be positive; limits and gap must be nonnegative");
        auto total_start = std::chrono::steady_clock::now();
        std::ifstream input(argv[1]);
        if (!input) throw std::runtime_error("Cannot open model");
        std::string path = argv[1];
        if(path.size()>=6 && path.substr(path.size()-6)==".qplib") {
            if(milp) throw std::runtime_error("MIQP is not supported");
            auto problem=sovereign::read_qplib(input);
            sovereign::QpOptions qo;qo.time_limit=options.time_limit_seconds;qo.threads=threads;
            qo.scaling=options.scaling;if(custom_iterations)qo.iteration_limit=options.iteration_limit;if(custom_tolerance)qo.tolerance=options.tolerance;
            if(backend=="cuda"&&!problem.linear.rows.empty())throw std::runtime_error("CUDA currently supports convex box QPs; use CPU for linearly constrained QP");
            auto result=problem.linear.rows.empty()?sovereign::solve_accelerated_box(problem,qo,backend=="cuda"):sovereign::solve_qp_admm(problem,qo);
            double seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-total_start).count();
            std::cout<<std::setprecision(17);
            if(json) {
                std::cout<<"{\"status\":\""<<result.status<<"\",\"algorithm\":\""<<result.algorithm<<"\",\"threads\":"<<threads<<",\"optimality_verified\":"<<(result.optimality_verified?"true":"false")<<",\"iterations\":"<<result.iterations
                         <<",\"total_seconds\":"<<seconds<<",\"rows\":"<<problem.linear.rows.size()
                         <<",\"columns\":"<<problem.linear.cost.size()<<",\"objective\":";numeric(result.objective);
                std::cout<<",\"primal_residual\":";numeric(result.primal_residual);
                std::cout<<",\"stationarity_residual\":";numeric(result.stationarity_residual);
                std::cout<<",\"complementarity_residual\":";numeric(result.complementarity_residual);
                std::cout<<",\"dual_bound_minimization_sense\":";numeric(result.dual_bound);
                std::cout<<",\"relative_gap\":";numeric(result.relative_gap);
                std::cout<<",\"primal\":";array(result.primal);
                std::cout<<",\"row_dual\":";array(result.row_dual);std::cout<<"}\n";
            } else std::cout<<"status: "<<result.status<<"\nobjective: "<<result.objective
                           <<"\niterations: "<<result.iterations<<"\nstationarity_residual: "<<result.stationarity_residual<<'\n';
            return result.status=="optimal"?0:1;
        }
        bool mps = path.size() >= 4 && (path.substr(path.size() - 4) == ".mps" || path.substr(path.size() - 4) == ".MPS");
        if(backend!="cpu")throw std::runtime_error("CUDA currently supports QPLIB box QPs only");
        sovereign::Model m;
        sovereign::LinearProblem problem;
        sovereign::StandardForm standard;
        std::size_t row_count = 0, col_count = 0, nonzeros = 0;
        if (mps) {
            problem = sovereign::read_mps(input);
            if (milp) {
                mip_options.lp = options;
                auto result = sovereign::solve_milp(problem, mip_options);
                double seconds = std::chrono::duration<double>(std::chrono::steady_clock::now()-total_start).count();
                std::cout << std::setprecision(17);
                if (!json) {
                    std::cout << "status: " << result.status << "\nnodes: " << result.nodes
                              << "\nobjective: " << result.objective << "\nbest_bound: " << result.best_bound
                              << "\ngap: " << result.gap << "\nseconds: " << seconds << '\n';
                } else {
                    std::cout << "{\"status\":\"" << result.status << "\",\"message\":\""<<result.message<<"\",\"nodes\":" << result.nodes
                              << ",\"lp_iterations\":" << result.lp_iterations << ",\"total_seconds\":" << seconds
                              << ",\"warm_starts\":"<<result.warm_starts<<",\"heuristic_solves\":"<<result.heuristic_solves<<",\"cuts\":"<<result.cuts<<",\"bound_tightenings\":"<<result.bound_tightenings
                              << ",\"rows\":" << problem.rows.size() << ",\"columns\":" << problem.names.size()
                              << ",\"objective\":"; numeric(result.objective);
                    std::cout << ",\"pump_projections\":" << result.pump_projections << ",\"pump_restarts\":" << result.pump_restarts
                              << ",\"pump_incumbents\":" << result.pump_incumbents << ",\"cut_rollbacks\":" << result.cut_rollbacks
                              << ",\"first_incumbent_seconds\":"; numeric(result.first_incumbent_seconds);
                    std::cout << ",\"best_bound\":"; numeric(result.best_bound);
                    std::cout << ",\"branching\":\"" << mip_options.branching << "\",\"pseudocost_updates\":" << result.pseudocost_updates
                              << ",\"strong_branch_probes\":" << result.strong_branch_probes << ",\"strong_branch_seconds\":";numeric(result.strong_branch_seconds);
                    std::cout << ",\"gap\":"; numeric(result.gap);
                    std::cout << ",\"lp_recovery_attempts\":"<<result.lp_recovery_attempts<<",\"lp_recovery_successes\":"<<result.lp_recovery_successes<<",\"lp_recovery_seconds\":";numeric(result.lp_recovery_seconds);
                    std::cout << ",\"deferred_nodes\":"<<result.deferred_nodes<<",\"unresolved_nodes\":"<<result.unresolved_nodes
                              << ",\"neighborhood_calls\":"<<result.neighborhood_calls<<",\"neighborhood_nodes\":"<<result.neighborhood_nodes
                              << ",\"neighborhood_improvements\":"<<result.neighborhood_improvements<<",\"neighborhood_seconds\":";numeric(result.neighborhood_seconds);
                    std::cout << ",\"first_lp_failure\":";lp_failure(result.first_lp_failure);
                    std::cout << ",\"rejected_integer_candidates\":"<<result.rejected_integer_candidates<<",\"rejected_candidates\":[";
                    for(std::size_t k=0;k<result.rejected_candidates.size();++k){
                        if(k)std::cout<<',';const auto& sample=result.rejected_candidates[k];
                        std::cout<<"{\"fixing\":";lp_failure(sample.fixing);
                        std::cout<<",\"relaxation\":";array(sample.relaxation);std::cout<<",\"rounded\":";array(sample.rounded);std::cout<<",\"repair_primal\":";array(sample.repair_primal);
                        std::cout<<",\"node_lower\":";array(sample.node_lower);std::cout<<",\"node_upper\":";array(sample.node_upper);
                        std::cout<<",\"relaxation_violation\":";numeric(sample.relaxation_violation);std::cout<<",\"rounded_violation\":";numeric(sample.rounded_violation);std::cout<<",\"repair_violation\":";numeric(sample.repair_violation);
                        std::cout<<",\"repair_infeasibility_verified\":"<<(sample.repair_infeasibility_verified?"true":"false")<<",\"repair_optimality_verified\":"<<(sample.repair_optimality_verified?"true":"false")<<",\"repair_accepted\":"<<(sample.repair_accepted?"true":"false");
                        std::cout<<",\"fallback_status\":\""<<sample.fallback_status<<"\",\"fallback_accepted\":"<<(sample.fallback_accepted?"true":"false")<<",\"fallback_primal\":";array(sample.fallback_primal);std::cout<<'}';
                    }
                    std::cout<<']';
                    std::cout<<",\"candidate_repair_attempts\":"<<result.candidate_repair_attempts<<",\"candidate_repair_successes\":"<<result.candidate_repair_successes<<",\"repair_branch_nodes\":"<<result.repair_branch_nodes<<",\"candidate_repair_seconds\":";numeric(result.candidate_repair_seconds);
                    std::cout << ",\"incumbent_trace\":[";
                    for(std::size_t k=0;k<result.incumbent_trace.size();++k){if(k)std::cout<<',';std::cout<<'[';numeric(result.incumbent_trace[k].first);std::cout<<',';numeric(result.incumbent_trace[k].second);std::cout<<']';}
                    std::cout << ']';
                    std::cout << ",\"primal\":"; array(result.primal); std::cout << "}\n";
                }
                return result.status == "optimal" || result.status == "gap_limit" ? 0 : 1;
            }
            if(lp_method=="dense") {standard = sovereign::standardize(problem, options.max_tableau_cells);m = standard.model;}
            row_count = problem.rows.size(); col_count = problem.cost.size();
            for (const auto& row : problem.rows) nonzeros += row.size();
        } else {
        if (milp) throw std::runtime_error("MILP input requires MPS with integer declarations");
        long long n, rows;
        if (!(input >> n >> rows) || n <= 0 || rows < 0 || n > 1000 || rows > 1000)
            throw std::runtime_error("Invalid dimensions (prototype limit: 1000 each)");
        m.cost.resize(static_cast<std::size_t>(n));
        m.rows.assign(static_cast<std::size_t>(rows), std::vector<double>(n));
        m.rhs.resize(static_cast<std::size_t>(rows));
        for (double& c : m.cost) if (!(input >> c)) throw std::runtime_error("Invalid objective");
        for (std::size_t i = 0; i < m.rows.size(); ++i) {
            for (double& a : m.rows[i]) if (!(input >> a)) throw std::runtime_error("Invalid row");
            if (!(input >> m.rhs[i])) throw std::runtime_error("Missing RHS");
        }
        std::string extra;
        if (input >> extra) throw std::runtime_error("Unexpected trailing input");
        row_count = m.rows.size(); col_count = m.cost.size();
        for (const auto& row : m.rows) for (double a : row) nonzeros += a != 0;
        }
        auto start = std::chrono::steady_clock::now();
        sovereign::SparseLpResult sparse_result;
        sovereign::Result r;
        if(lp_method=="sparse") {
            sparse_result=sovereign::solve_sparse_lp(mps?problem:sovereign::linear_from_dense(m),options);
            r=sparse_result.solution;
        } else r=sovereign::solve(m, options);
        double elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count();
        double original_scaled = r.scaled_primal_violation;
        auto canonical_primal = lp_method=="sparse"?sparse_result.canonical_primal:r.primal;
        if (mps && lp_method=="dense" && !r.primal.empty()) {
            r.primal = standard.recover(r.primal);
            r.objective = problem.offset;
            for (std::size_t j = 0; j < r.primal.size(); ++j) r.objective += problem.cost[j] * r.primal[j];
            r.max_violation = sovereign::original_violation(problem, r.primal, false);
            original_scaled = sovereign::original_violation(problem, r.primal, true);
            if (!std::isfinite(r.objective) || original_scaled > 10 * options.tolerance) {
                r.status = "numerical_error"; r.optimality_verified = false;
            }
        }
        double total = std::chrono::duration<double>(std::chrono::steady_clock::now() - total_start).count();
        std::cout << std::setprecision(17);
        if (json) {
            std::cout << "{\"status\":\"" << r.status << "\",\"algorithm\":\""<<lp_method<<"_simplex\",\"rows\":" << row_count << ",\"columns\":" << col_count
                      << ",\"nonzeros\":" << nonzeros << ",\"iterations\":" << r.iterations
                      << ",\"solve_seconds\":" << elapsed << ",\"total_seconds\":" << total << ",\"objective\":";
            if (r.primal.empty()) std::cout << "null"; else numeric(r.objective);
            std::cout << ",\"max_primal_violation\":"; numeric(r.max_violation);
            std::cout << ",\"scaled_primal_violation\":"; numeric(original_scaled);
            std::cout << ",\"scaled_dual_violation\":"; numeric(r.scaled_dual_violation);
            std::cout << ",\"relative_gap\":"; numeric(r.relative_gap);
            std::cout << ",\"optimality_verified\":" << (r.optimality_verified ? "true" : "false");
            std::cout << ",\"infeasibility_verified\":" << (r.infeasibility_verified ? "true" : "false");
            std::cout << ",\"unboundedness_verified\":" << (r.unboundedness_verified ? "true" : "false");
            std::cout << ",\"unbounded_ray\":";array(r.unbounded_ray);
            std::cout << ",\"primal\":"; array(r.primal);
            std::cout << ",\"canonical_primal\":"; array(canonical_primal);
            std::cout << ",\"canonical_dual\":"; array(r.dual);
            std::cout << "}\n";
        } else {
        std::cout << "status: " << r.status << "\niterations: " << r.iterations
                  << "\nseconds: " << elapsed << '\n';
        if (!r.primal.empty()) {
            std::cout << "objective: " << r.objective << "\nmax_primal_violation: " << r.max_violation
                      << "\nrelative_gap: " << r.relative_gap << "\noptimality_verified: " << r.optimality_verified << '\n';
            for (std::size_t j = 0; j < r.primal.size(); ++j)
                std::cout << "x[" << j << "]: " << r.primal[j] << '\n';
        }
        }
        return r.status == "optimal" ? 0 : 1;
    } catch (const std::exception& e) { std::cerr << "error: " << e.what() << '\n'; return 2; }
}
