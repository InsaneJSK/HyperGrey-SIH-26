# Focused hard-MILP comparison

One sequential run per strategy/model, alternating order by model; equal time/node/gap limits. References after all timed runs. CPU only.

| Model | Strategy | Status | Objective | Gap | Verified candidate |
| --- | --- | --- | ---: | ---: | --- |
| blend2 | baseline | time_limit | None | None | False |
| blend2 | candidate_repair | time_limit | 8.015188 | 0.050051084121017074 | True |

Generated correctness: True.

Experimental options are not promoted based on one timing pass. Limits and unresolved relaxations remain incomplete results, not infeasibility or optimality.

Inspect results.json, raw candidate/reference files, and incumbent_trace before choosing a default.
