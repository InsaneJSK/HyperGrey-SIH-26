#pragma once
#include "mps.hpp"
#include "sparse_lp.hpp"

namespace sovereign {
struct MilpOptions {
    Options lp;
    std::size_t node_limit = 10000;
    double integer_tolerance = 1e-7;
    double relative_gap = 1e-6;
    bool presolve = true;
    bool heuristics = true;
    bool feasibility_pump = true;
    bool cover_cuts = true;
    // Experimental choice remains opt-in until paired hard-instance evidence.
    std::string branching = "fractionality";
    bool lp_recovery = false;
    bool improve_incumbent = false;
    bool capture_lp_failure = false;
    bool capture_rejected_candidates = false;
    bool repair_candidates = false;
};
struct MilpLpFailure {
    LinearProblem model;
    LpBasis input_basis;
    std::string status;
    std::size_t node=0,depth=0,iterations=0;
    double parent_bound=-std::numeric_limits<double>::infinity();
    bool captured=false;
};
struct MilpResult {
    std::string status;
    std::vector<double> primal;
    double objective = std::numeric_limits<double>::quiet_NaN();
    double best_bound = -std::numeric_limits<double>::infinity();
    double gap = std::numeric_limits<double>::infinity();
    std::size_t nodes = 0;
    std::size_t lp_iterations = 0;
    std::size_t warm_starts = 0, heuristic_solves = 0, cuts = 0, bound_tightenings = 0;
    std::size_t pump_projections = 0, pump_restarts = 0, pump_incumbents = 0;
    std::size_t cut_rollbacks = 0;
    std::size_t pseudocost_updates = 0, strong_branch_probes = 0;
    double strong_branch_seconds = 0;
    std::size_t lp_recovery_attempts=0,lp_recovery_successes=0,deferred_nodes=0,unresolved_nodes=0;
    double lp_recovery_seconds=0;
    std::size_t neighborhood_calls=0,neighborhood_nodes=0,neighborhood_improvements=0;
    double neighborhood_seconds=0;
    MilpLpFailure first_lp_failure;
    struct RejectedCandidate {
        MilpLpFailure fixing;
        std::vector<double> relaxation,rounded,repair_primal,node_lower,node_upper,fallback_primal;
        std::string fallback_status;
        double relaxation_violation=0,rounded_violation=0,repair_violation=0;
        bool repair_infeasibility_verified=false,repair_optimality_verified=false,repair_accepted=false;
        bool fallback_accepted=false;
    };
    std::size_t rejected_integer_candidates=0;
    std::vector<RejectedCandidate> rejected_candidates;
    std::size_t candidate_repair_attempts=0,candidate_repair_successes=0,repair_branch_nodes=0;
    double candidate_repair_seconds=0;
    std::vector<std::pair<double,double> > incumbent_trace; // seconds, original-sense objective
    double first_incumbent_seconds = std::numeric_limits<double>::quiet_NaN();
    std::string message;
};
MilpResult solve_milp(const LinearProblem&, const MilpOptions& = MilpOptions());
}
