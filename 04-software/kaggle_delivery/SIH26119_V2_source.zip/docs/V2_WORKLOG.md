# SIH26119 implementation worklog

This continues the supplied V1 conversation and evidence. The user's current
instruction is to build a strong, working submission covering the PS, with tests,
phase reports, and explicit limitations. Existing V1 reports are historical.

## Delivery contract

- Initial classes: LP, MILP, and continuous convex QP. The PS asks for an
  architecture extensible to MIQP/NLP/MINLP; it does not require all of these
  extensions to be implemented initially. Nonconvex-QP scope is unresolved.
- All optimization and numerical algorithms in the core are our implementation.
  External solver packages are permitted only as isolated validation references.
- Keep unsuccessful benchmark runs. Optimal status requires numerical checks.
- GPU performance must be measured on available hardware, never inferred from
  a CPU run or a kernel-only timing.

## Current machine (2026-09-14)

Intel Core i5-10210U, 4 physical cores / 8 logical processors,
42,523,881,472 bytes physical RAM, Intel UHD Graphics. GCC 14.2.0 and CMake
3.30.4 are available. NVIDIA hardware is not detected. The user confirmed
30 September 2026 as the deadline and Kaggle as the GPU execution environment.

## Implementation and verification sequence

1. Preserve V1; establish a modern-compiler baseline.
2. Add sparse LP computation, reusable basis solves, and numerical certificates.
3. Add MILP presolve, incumbent heuristics, improved search and reusable LP state.
4. Strengthen constrained convex QP, scaling, PSD checks and stopping evidence.
5. Add multicore operations and an optional GPU backend with device detection.
6. Exercise analytical, generated, old-failure and broader public datasets;
   record source/input/binary hashes, hardware, timing, memory and reference checks.
7. Add literature-grounded industrial cases and submission documentation,
   including API/CLI usage, architecture, provenance, results and unresolved gaps.

This list records intended work, not implemented capabilities. Completed phases
and final evidence will be recorded below as they are verified.

## Implemented and assessed

- Preserved V1 source and executable in `reports/v2-baseline/`.
- Added sparse primal/dual revised simplex, own LU/eta basis algebra and warm
  starts; all 120 generated LP tests and the 12-instance Netlib subset passed.
- Added propagation, root cover cuts, diving and integer-candidate polishing;
  all 40 binary and 40 mixed/general-integer regressions passed. All four
  historical MIPLIB cases completed to the stated tolerance in the V2 run.
- Added scaled ADMM/PCG, bounded active-set polishing, broader sparse PSD tests,
  and a small structured diagonal-QP dual-Newton path. Generated QP checks pass;
  QPLIB 9002 remains incomplete.
- Added OpenMP and optional resident CUDA box-QP code. Repeated CPU scale tests
  through one million variables passed; actual CUDA execution awaits Kaggle.
- Added three MIPLIB 2017 stress cases, four industrial/literature models,
  a consolidated evidence runner, and a separate self-contained Kaggle notebook.
- Added current requirements, architecture, limitation and handoff documents.

The deadline is now confirmed as 30 September 2026. See `V2_REMAINING.md` for
the exact Kaggle return bundle and outside information still needed.

## Kaggle usability revision

After the user reported a notebook error and requested a simpler iteration,
the delivery was reduced to two code cells. It uses the current Kaggle Python,
standard pip/subprocess, explicit working paths, a single timing repetition,
and a results ZIP on normal installation/build/check errors. Missing GPU/CUDA
is labeled CPU-only. The numerical solver was not changed. The original
traceback was not supplied, so its exact cause is not asserted.

The user subsequently reported a notebook/kernel size limit of less than 1 MB.
The source/data payload was moved out of the notebook into a required companion
ZIP, attached as a private Kaggle input dataset. The notebook automatically
loads zipped or unpacked inputs and verifies their hashes before running.
No numerical solver or benchmark scope changes were needed for this packaging fix.
