# V2 limitation register

1. **Convex QP scope:** only continuous convex QPs. Conservative numerical PSD
   tests can reject some valid matrices when fill budgets are exhausted. Global
   nonconvex QP, MIQP, NLP and MINLP are not implemented.
2. **Constrained-QP convergence:** QPLIB `9002` is still an incomplete solve.
   It must not be treated as optimal from its objective alone. Sparse KKT
   polishing has a bounded attempt budget; bad active sets are discarded.
3. **Modern MILP difficulty:** the added `markshare_4_0`, `blend2` and
   `binkar10_1` stress cases remain incomplete under the local test limits.
   Historical four-case MIPLIB success is not modern industrial MILP coverage.
4. **Sparse factorization:** sparse storage removes the dense-tableau architecture
   from the main LP/MILP path, but LU fill, refactoring and basis conditioning
   still limit difficult problems. A small-problem dense recovery path remains.
5. **Numerical certificates:** LP and MILP checks use floating-point tolerances.
   MILP bounds have a safety margin, not an exact/interval proof. QP optimality
   uses KKT checks; its objective-error bound may be unavailable on unbounded
   boxes. General QP infeasibility/unboundedness certificates remain incomplete.
6. **GPU scope and evidence:** CUDA currently accelerates box QPs only and uses
   one GPU. No actual NVIDIA execution has occurred on this local Intel-only
   machine. GPU claims require the notebook's successful checks and measured runs.
7. **Parallel scope:** OpenMP parallelizes QP products/iterations. LP and MILP
   search remain sequential. Four threads can be slower than one on small cases.
8. **Scale interpretation:** the million-variable experiment is synthetic,
   sparse, convex, box-constrained and has a planted optimum. It does not prove
   general industrial-scale LP/MILP/constrained-QP performance.
9. **Dataset and industrial coverage:** selections are small. Mittelmann runs
   are pending. Literature examples are historical teaching cases, not MRPL
   production data; the multi-period production inputs are synthetic.
10. **Format/platform limits:** MPS/QPLIB remain documented subsets. Local tests
    use GCC 14.2 on Windows. CUDA and Linux execution must be verified on Kaggle.
11. **Resource accounting:** host/device memory sampling can miss short peaks.
    Parsing, curvature checking, setup and an individual numerical operation
    can slightly overrun limits. The Python harness enforces an external timeout.
12. **Open questions:** numerical-library/GPU-runtime permissions, convex-QP
    acceptance, and the supplied statement's truncated final paragraph remain
    outside information gaps. The confirmed deadline is 30 September 2026.
