# Build and verify V2

Use the project directory containing CMakeLists.txt. The Windows local project
and the separate Kaggle delivery are independent copies of the same source
snapshot. The notebook never accesses or changes the Windows workspace.

## Local CPU build

```powershell
cmake -S . -B build-v2 -G "MinGW Makefiles" -DCMAKE_BUILD_TYPE=Release
cmake --build build-v2 -j 4
ctest --test-dir build-v2 --output-on-failure
./build-v2/solver_cli.exe examples/blending.lpmini --json
./build-v2/solver_cli.exe examples/production.mps --milp --json
./build-v2/solver_cli.exe examples/dispatch.qplib --json
./build-v2/solver_cli.exe examples/industrial/marco_refinery.mps --json
```

On Linux omit the generator argument and `.exe` suffix. The core needs a C++11
compiler and CMake; OpenMP is detected optionally. GPU builds additionally need
NVIDIA hardware and CUDA, using `-DSOVEREIGN_ENABLE_CUDA=ON`.

## CLI controls

`--json`, `--time-limit SECONDS`, `--iteration-limit N`, `--tolerance VALUE`,
`--lp-method sparse|dense`, `--milp`, `--node-limit N`, `--gap VALUE`,
`--no-presolve`, `--no-heuristics`, `--no-cuts`, `--no-scaling`,
`--threads N`, `--backend cpu|cuda`.

LP/MILP execution is sequential; `--threads` applies to sparse QP computation.
CUDA is supported for box QPs only. Thread count is a requested configuration;
very small CPU kernels intentionally remain serial to avoid launch overhead.

For a C++ application, include `sparse_lp.hpp`, `milp.hpp` or `qp.hpp` and link
the CMake `solver` target. `solve_sparse_lp(problem, options, &previous.basis)`
requests basis reuse. `solve_milp` and `solve_qp_admm` accept their corresponding
option structures. `accelerated_qp.hpp` exposes the CPU/CUDA box path.

## Full evidence run

Reference environments need HiGHS, OSQP, NumPy, SciPy and psutil. Existing local
reference wheels are supported. The simplified Kaggle notebook uses its current
Python interpreter and installs reference packages there with standard pip.

```powershell
python scripts/industrial_cases.py
python scripts/fetch_v2.py
python scripts/validate_v2.py --output reports/my-new-v2-run --limit 30 --sizes 10000 100000 1000000 --repeats 3
```

The output directory must be new. The runner preserves every public failure and
records all scale repetitions. It emits `summary.json`, `benchmarks.json`,
`scale.json`, `metadata.json`, `REPORT.md`, CTest logs, candidate solutions,
reference results and generated regression inputs. The preserved V1 generators
use an executable alias at `build/solver_cli.exe`, including on Linux.

The numerical library references are isolated from the C++ core. Do not compare
raw process times as kernel times: process times include startup/imports, whereas
the reported solve interval includes solver setup, transfers and solution checks.
RSS sampling every 20 milliseconds is an observed lower bound on peak memory.

## Separate Kaggle notebook

Run `python scripts/package_kaggle.py` to create/update the separate delivery
folder beside the local project. Its `.ipynb` stays below 1 MB. Upload the
companion `SIH26119_V2_source.zip` as a private Kaggle dataset and attach it
using Add Input. The source and cached public inputs are loaded from that
dataset automatically, whether zipped or unpacked. Internet is needed to install
the reference packages. Select an NVIDIA GPU before running it. There is no
second virtual environment and no manual path editing.

The notebook has two code cells: unpack, then install/build/run/export. It runs
the same CPU regressions and public cases, with CPU/multicore/GPU planted scale
checks at 1,000, 100,000 and 1,000,000 variables. This quick iteration uses one
timing repetition; repeated speedup measurements and additional public GPU
cross-checks can follow. Without a GPU/compiler it produces clearly labeled
CPU-only results. Installation/build/check failures also produce a diagnostic
`sih26119_kaggle_results.zip`. Return that ZIP to guide the next iteration.

The million-variable scale family is a synthetic tridiagonal convex box QP with
a planted optimum. It is useful for memory and accelerator measurements, but
does not demonstrate million-variable LP, MILP or general industrial QP support.
