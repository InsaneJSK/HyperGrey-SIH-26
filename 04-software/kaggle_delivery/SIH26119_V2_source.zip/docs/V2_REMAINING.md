# What is needed before final V2 submission

Deadline: 30 September 2026. The local implementation is a V2 candidate while
GPU execution and the remaining performance/robustness gaps are unresolved.

1. **Kaggle evidence:** import the small notebook and attach the companion source
   ZIP as a private Kaggle input dataset. Select an NVIDIA GPU,
   enable Internet for reference installation, and run all cells. Return
   `sih26119_kaggle_results.zip`. The simplified two-cell notebook includes
   hardware, CUDA build logs, planted GPU checks, CPU public-case comparisons,
   one timing pass, memory and hashes. Repeated GPU timings can follow once
   this first iteration runs successfully.
   If a cell fails, return the diagnostic zip it produces; do not edit results.
2. **Industrial relevance:** supply any MRPL-approved or shareable refinery,
   scheduling or supply-chain model, or domain-expert feedback on the literature
   case. Public teaching examples do not replace validation on actual operations.
3. **Organizer clarification:** confirm the acceptable QP scope (convex versus
   nonconvex) and use of GPU/general numerical infrastructure. No organizer
   approval has been obtained by this implementation work.
4. **Performance and robustness work:** preserve and improve constrained QPLIB
   `9002` and incomplete modern MIPLIB instances. An incomplete solve remains
   incomplete even if its candidate objective looks promising.
5. **Final report:** after the Kaggle result bundle is checked against the source
   snapshot, update GPU measurements, compare equal-accuracy runs, and finalize
   the PS requirement matrix and submission claims.

The PS's general ambition of reliable industrial-scale LP/MILP/QP up to millions
of variables is not established by a synthetic million-variable box QP. Complete
MIPLIB/Netlib/Mittelmann library coverage is not claimed. MIQP, NLP, MINLP and
global nonconvex QP are not implemented. Additional algorithms should be added
against explicit scope and test gates rather than counted as completed features.
