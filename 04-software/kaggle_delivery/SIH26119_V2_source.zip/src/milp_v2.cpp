#include "milp.hpp"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <queue>
#include <stdexcept>

namespace sovereign {
namespace {
const double inf=std::numeric_limits<double>::infinity();
struct Node {
    std::vector<double> lower,upper;
    double bound;
    std::size_t id,depth;
    LpBasis basis;
};
struct Order {
    bool operator()(const Node& a,const Node& b) const {
        if(a.bound!=b.bound)return a.bound>b.bound;
        if(a.depth!=b.depth)return a.depth<b.depth;
        return a.id>b.id;
    }
};
bool propagate(const LinearProblem& p,std::vector<double>& lo,std::vector<double>& up,std::size_t& changes) {
    for(std::size_t j=0;j<lo.size();++j) {
        if(p.integer[j]){lo[j]=std::ceil(lo[j]);up[j]=std::floor(up[j]);}
        if(lo[j]>up[j])return false;
    }
    for(int pass=0;pass<10;++pass) {
        bool changed=false;
        for(std::size_t i=0;i<p.rows.size();++i) {
            const auto& row=p.rows[i];
            long double minimum=0,maximum=0;int min_inf=0,max_inf=0;
            for(auto a:row) {
                if(a.second==0)continue;
                double low=a.second>0?lo[a.first]:up[a.first],high=a.second>0?up[a.first]:lo[a.first];
                if(std::isfinite(low))minimum+=static_cast<long double>(a.second)*low;else ++min_inf;
                if(std::isfinite(high))maximum+=static_cast<long double>(a.second)*high;else ++max_inf;
            }
            long double margin=1e-9L*(1+std::abs(minimum)+std::abs(maximum));
            if((!min_inf&&minimum>p.row_upper[i]+margin)||(!max_inf&&maximum<p.row_lower[i]-margin))return false;
            std::vector<std::pair<double,double> > proposed;
            for(auto a:row) {
                const std::size_t j=a.first;
                double low=a.second>0?lo[j]:up[j],high=a.second>0?up[j]:lo[j];
                double nl=lo[j],nu=up[j];
                auto tighten=[&](long double value,bool upper) {
                    double slack=1e-9*(1+std::abs(static_cast<double>(value)));
                    if(upper)nu=std::min(nu,static_cast<double>(value)+slack);else nl=std::max(nl,static_cast<double>(value)-slack);
                };
                if(a.second!=0&&std::isfinite(p.row_upper[i])&&min_inf-(!std::isfinite(low))==0) {
                    long double other=minimum-(std::isfinite(low)?static_cast<long double>(a.second)*low:0);
                    tighten((p.row_upper[i]-other)/a.second,a.second>0);
                }
                if(a.second!=0&&std::isfinite(p.row_lower[i])&&max_inf-(!std::isfinite(high))==0) {
                    long double other=maximum-(std::isfinite(high)?static_cast<long double>(a.second)*high:0);
                    tighten((p.row_lower[i]-other)/a.second,a.second<0);
                }
                if(p.integer[j]){nl=std::ceil(nl);nu=std::floor(nu);}
                if(nl>nu)return false;
                proposed.push_back({nl,nu});
            }
            // Apply together: all implied bounds were derived from the same row sums.
            for(std::size_t k=0;k<row.size();++k) {
                auto j=row[k].first;
                if(proposed[k].first>lo[j]+1e-10||proposed[k].second<up[j]-1e-10){changed=true;++changes;}
                lo[j]=proposed[k].first;up[j]=proposed[k].second;
            }
        }
        if(!changed)break;
    }
    return true;
}
std::size_t add_covers(LinearProblem& p,const std::vector<double>& x) {
    std::size_t added=0,original_rows=p.rows.size();
    for(std::size_t i=0;i<original_rows&&added<16;++i)for(int side=0;side<2&&added<16;++side) {
        double bound=side?p.row_lower[i]:p.row_upper[i],sign=side?-1:1;
        if(!std::isfinite(bound))continue;
        bound*=sign;
        struct Item {std::size_t j;double weight,z;bool complement;};std::vector<Item> items;bool valid=true;
        for(auto a:p.rows[i]) {
            if(a.second==0)continue;
            if(!p.integer[a.first]||p.lower[a.first]<0||p.upper[a.first]>1){valid=false;break;}
            double weight=sign*a.second;bool complement=weight<0;
            if(complement)bound-=weight;
            items.push_back({a.first,std::abs(weight),complement?1-x[a.first]:x[a.first],complement});
        }
        if(!valid||items.empty())continue;
        std::sort(items.begin(),items.end(),[](const Item& a,const Item& b){return a.z==b.z?a.weight>b.weight:a.z>b.z;});
        double sum=0,activity=0;std::size_t count=0;
        while(count<items.size()&&sum<=bound+1e-8*(1+std::abs(bound))) {sum+=items[count].weight;activity+=items[count].z;++count;}
        if(sum<=bound+1e-8*(1+std::abs(bound))||activity<=static_cast<double>(count)-1+1e-7)continue;
        SparseVector cut;double rhs=static_cast<double>(count)-1;
        for(std::size_t k=0;k<count;++k){cut.push_back({items[k].j,items[k].complement?-1.0:1.0});if(items[k].complement)rhs-=1;}
        std::sort(cut.begin(),cut.end());bool duplicate=false;
        for(std::size_t r=0;r<p.rows.size();++r)if(p.rows[r]==cut&&p.row_upper[r]==rhs)duplicate=true;
        if(!duplicate){p.rows.push_back(cut);p.row_lower.push_back(-inf);p.row_upper.push_back(rhs);++added;}
    }
    return added;
}
}
MilpResult solve_milp(const LinearProblem& original,const MilpOptions& opt) {
    validate_linear_problem(original);
    if(opt.integer_tolerance<=0||!std::isfinite(opt.integer_tolerance)||opt.relative_gap<0||!std::isfinite(opt.relative_gap))
        throw std::invalid_argument("Invalid MILP tolerances");
    MilpResult out;LinearProblem p=original;auto start=std::chrono::steady_clock::now();
    for(auto& row:p.rows){std::map<std::size_t,double> a;for(auto v:row)a[v.first]+=v.second;row.clear();for(auto v:a)if(v.second!=0)row.push_back(v);}
    double sign=p.maximize?-1:1,incumbent=inf;
    auto remaining=[&](){return std::max(0.0,opt.lp.time_limit_seconds-std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count());};
    auto accept=[&](std::vector<double> x) {
        if(x.size()!=p.cost.size())return false;
        for(std::size_t j=0;j<x.size();++j)if(p.integer[j]) {
            if(std::abs(x[j]-std::round(x[j]))>opt.integer_tolerance)return false;
            x[j]=std::round(x[j]);
        }
        if(original_violation(original,x,false)>1e-7)return false;
        double value=sign*p.offset;for(std::size_t j=0;j<x.size();++j)value+=sign*p.cost[j]*x[j];
        if(std::isfinite(value)&&value<incumbent){incumbent=value;out.primal=x;out.objective=sign*value;}
        return std::isfinite(value);
    };
    auto relax=[&](const Node& node,bool heuristic) {
        LinearProblem model=p;model.lower=node.lower;model.upper=node.upper;
        std::fill(model.integer.begin(),model.integer.end(),false);
        Options o=opt.lp;o.time_limit_seconds=remaining();
        auto r=solve_sparse_lp(model,o,node.basis.columns.empty()?nullptr:&node.basis);
        if(r.solution.status=="numerical_error"||r.solution.status=="numerical_stall") {
            // Independent algorithmic recovery on small, difficult bases.
            try {
                auto standard=standardize(model,o.max_tableau_cells);o.time_limit_seconds=remaining();
                auto dense=solve(standard.model,o);out.lp_iterations+=r.solution.iterations;
                if(dense.status=="optimal"&&dense.optimality_verified) {
                    long double dual=0;for(std::size_t i=0;i<dense.dual.size();++i)dual+=standard.model.rhs[i]*dense.dual[i];
                    r.best_bound=static_cast<double>(dual)+sign*standard.objective_offset;
                    dense.primal=standard.recover(dense.primal);dense.objective=model.offset;
                    for(std::size_t j=0;j<dense.primal.size();++j)dense.objective+=model.cost[j]*dense.primal[j];
                    r.solution=dense;r.basis={};
                } else if(dense.status=="infeasible"&&dense.infeasibility_verified){r.solution=dense;r.basis={};}
            } catch(const std::runtime_error&) { /* Preserve the original failure if recovery exceeds its resource budget. */ }
        }
        out.lp_iterations+=r.solution.iterations;out.warm_starts+=r.warm_started;
        if(heuristic)++out.heuristic_solves;
        return r;
    };
    std::priority_queue<Node,std::vector<Node>,Order> queue;
    Node root={p.lower,p.upper,-inf,0,0,{}};queue.push(root);std::size_t serial=1;
    out.status="optimal";
    while(!queue.empty()) {
        if(remaining()<=0){out.status="time_limit";break;}
        if(out.nodes>=opt.node_limit){out.status="node_limit";break;}
        if(std::isfinite(incumbent)&&queue.top().bound>=incumbent-opt.relative_gap*(1+std::abs(incumbent))){out.status="gap_limit";break;}
        Node node=queue.top();queue.pop();++out.nodes;
        if(opt.presolve&&!propagate(p,node.lower,node.upper,out.bound_tightenings))continue;
        auto lp=relax(node,false);
        if(lp.solution.status=="infeasible"&&lp.solution.infeasibility_verified)continue;
        if(lp.solution.status!="optimal"||!lp.solution.optimality_verified) {
            queue.push(node);out.status=lp.solution.status=="unbounded"?"unbounded_relaxation":lp.solution.status;
            out.message="LP relaxation did not pass its numerical checks";break;
        }
        if(node.depth==0&&opt.cover_cuts) {
            for(int pass=0;pass<5;++pass) {
                auto added=add_covers(p,lp.solution.primal);out.cuts+=added;if(!added)break;
                node.basis={};lp=relax(node,false);if(lp.solution.status!="optimal")break;
            }
            if(lp.solution.status=="infeasible"&&lp.solution.infeasibility_verified)continue;
            if(lp.solution.status!="optimal"||!lp.solution.optimality_verified){queue.push(node);out.status=lp.solution.status;break;}
        }
        node.basis=lp.basis;node.bound=std::max(node.bound,lp.best_bound-100*opt.lp.tolerance*(1+std::abs(lp.best_bound)));
        if(node.bound>=incumbent)continue;
        auto x=lp.solution.primal;accept(x);
        if(opt.heuristics&&(out.nodes==1||(out.primal.empty()&&out.nodes%100==0))) {
            double budget=std::min(2.0,remaining()*.2),until=remaining()-budget;
            for(int mode=0;mode<2&&remaining()>until;++mode) {
                Node dive=node;auto dx=x;
                for(std::size_t step=0;step<64&&remaining()>until;++step) {
                    std::size_t branch=p.cost.size();double fraction=opt.integer_tolerance;
                    for(std::size_t j=0;j<dx.size();++j)if(p.integer[j]&&std::abs(dx[j]-std::round(dx[j]))>fraction) {
                        branch=j;fraction=std::abs(dx[j]-std::round(dx[j]));
                    }
                    if(branch==p.cost.size()){accept(dx);break;}
                    bool up=mode?sign*p.cost[branch]<0:dx[branch]-std::floor(dx[branch])>=.5;
                    Node alternate=dive;
                    if(up){dive.lower[branch]=std::ceil(dx[branch]);alternate.upper[branch]=std::floor(dx[branch]);}
                    else {dive.upper[branch]=std::floor(dx[branch]);alternate.lower[branch]=std::ceil(dx[branch]);}
                    auto attempt=[&](Node& d){if(opt.presolve&&!propagate(p,d.lower,d.upper,out.bound_tightenings)){SparseLpResult bad;bad.solution.status="infeasible";return bad;}return relax(d,true);};
                    auto trial=attempt(dive);
                    if(trial.solution.status!="optimal"){dive=alternate;trial=attempt(dive);}
                    if(trial.solution.status!="optimal")break;
                    dive.basis=trial.basis;dx=trial.solution.primal;accept(dx);
                }
            }
        }
        std::size_t branch=p.cost.size();double score=opt.integer_tolerance;
        for(std::size_t j=0;j<x.size();++j)if(p.integer[j]) {
            double fractional=std::abs(x[j]-std::round(x[j]));
            if(fractional>score){score=fractional;branch=j;}
        }
        if(branch==p.cost.size()) {
            if(!accept(x)) {
                LinearProblem fixed=original;
                for(std::size_t j=0;j<x.size();++j)if(p.integer[j])fixed.lower[j]=fixed.upper[j]=std::round(x[j]);
                std::fill(fixed.integer.begin(),fixed.integer.end(),false);
                Options polish_options=opt.lp;polish_options.tolerance=std::min(1e-11,opt.lp.tolerance);polish_options.time_limit_seconds=remaining();
                auto polished=solve_sparse_lp(fixed,polish_options);out.lp_iterations+=polished.solution.iterations;++out.heuristic_solves;
                if(polished.solution.status=="optimal"&&accept(polished.solution.primal))continue;
                for(std::size_t j=0;j<x.size();++j)if(p.integer[j])x[j]=std::round(x[j]);
                queue.push(node);out.status="numerical_error";
                out.message="Rounded integer candidate violation "+std::to_string(original_violation(original,x,false));break;
            }
            continue;
        }
        Node down=node,up=node;down.upper[branch]=std::floor(x[branch]);up.lower[branch]=std::ceil(x[branch]);
        down.depth=up.depth=node.depth+1;down.id=serial++;up.id=serial++;
        if(down.lower[branch]<=down.upper[branch])queue.push(std::move(down));
        if(up.lower[branch]<=up.upper[branch])queue.push(std::move(up));
    }
    if(queue.empty()) {
        if(out.primal.empty())out.status="infeasible";
        out.best_bound=out.primal.empty()?sign*inf:out.objective;out.gap=out.primal.empty()?inf:0;
    } else {
        double bound=std::min(queue.top().bound,incumbent);out.best_bound=sign*bound;
        if(std::isfinite(incumbent)&&std::isfinite(bound))out.gap=std::max(0.0,incumbent-bound)/(1+std::abs(incumbent));
    }
    return out;
}
}
