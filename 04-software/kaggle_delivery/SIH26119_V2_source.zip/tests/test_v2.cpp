#include "sparse_lp.hpp"
#include "accelerated_qp.hpp"
#include "milp.hpp"
#include <iostream>

void require(bool condition,const char* text){if(!condition)throw std::runtime_error(text);}
int main(){try{
    sovereign::SparseLU lu;
    std::vector<sovereign::SparseVector> columns={{{0,0},{1,2},{2,1}},{{0,1},{1,3}},{{0,2},{2,4}}};
    require(lu.factor(columns),"Sparse LU pivoting failed");
    auto x=lu.solve({8,8,13});
    require(std::abs(x[0]-1)<1e-10&&std::abs(x[1]-2)<1e-10&&std::abs(x[2]-3)<1e-10,"LU forward solve wrong");
    auto y=lu.solve({7,7,14},true);
    require(std::abs(y[0]-1)<1e-10&&std::abs(y[1]-2)<1e-10&&std::abs(y[2]-3)<1e-10,"LU transpose solve wrong");
    auto unbounded=sovereign::solve_sparse_lp(sovereign::linear_from_dense({{-1},{{-1}},{-2}}));
    require(unbounded.solution.status=="unbounded"&&unbounded.solution.unboundedness_verified&&unbounded.solution.unbounded_ray[0]>0,"Missing validated unbounded ray");
    sovereign::QuadraticProblem q;auto& p=q.linear;
    const std::size_t n=300;p.names.resize(n);p.cost.assign(n,-1);p.lower.assign(n,0);p.upper.assign(n,10);p.integer.assign(n,false);
    for(std::size_t j=0;j<n;++j){p.names[j]="x"+std::to_string(j);q.hessian.push_back({j,j,j%2?5.0:1.0});if(j%2)q.hessian.push_back({j,j-1,2.0});}
    require(sovereign::check_convex_hessian(q),"Large PSD non-diagonally-dominant Hessian rejected");
    sovereign::QpOptions options;options.time_limit=10;
    auto r=sovereign::solve_accelerated_box(q,options,false);
    require(r.status=="optimal"&&r.optimality_verified,"Large PSD box QP failed");
    q.hessian[0].value=-1;require(!sovereign::check_convex_hessian(q),"Indefinite Hessian accepted");
    sovereign::QuadraticProblem diagonal;auto& dp=diagonal.linear;
    dp.names={"a","b","c"};dp.cost={-4,-10,-20};dp.lower={0,0,0};dp.upper={10,10,10};dp.integer={false,false,false};
    dp.rows={{{0,1},{1,1},{2,1}}};dp.row_lower={6};dp.row_upper={6};diagonal.hessian={{0,0,2},{1,1,4},{2,2,6}};
    auto equality=sovereign::solve_qp_admm(diagonal);
    require(equality.status=="optimal"&&std::abs(equality.objective+48)<1e-6,"Diagonal equality QP failed");
    dp.lower[0]=dp.upper[0]=1;equality=sovereign::solve_qp_admm(diagonal);
    require(equality.status=="optimal"&&std::abs(equality.objective+48)<1e-6,"Fixed-variable diagonal QP failed");
    dp.maximize=true;for(double& v:dp.cost)v=-v;for(auto& h:diagonal.hessian)h.value=-h.value;
    equality=sovereign::solve_qp_admm(diagonal);require(equality.status=="optimal"&&std::abs(equality.objective-48)<1e-6,"Concave maximization QP normalization failed");
    sovereign::QuadraticProblem linear;linear.linear=sovereign::linear_from_dense({{-1e-12},{},{}});
    auto linear_qp=sovereign::solve_accelerated_box(linear,options,false);require(linear_qp.status=="unbounded","Zero-Hessian unbounded QP misclassified");
    bool rejected=false;try{options.threads=0;sovereign::solve_accelerated_box(q,options,false);}catch(const std::invalid_argument&){rejected=true;}
    require(rejected,"Invalid thread setting accepted");
    std::cout<<"V2 sparse LU, transpose, ray, extended PSD and option regressions passed\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
